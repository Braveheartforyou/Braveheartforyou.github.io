<template>
  <div class="campaign-kols-container">
    <create-process :renderData="processStatus"></create-process>

    <div class="campaign-kols-content">
      <status-area :statusData="detailData.status"></status-area>

      <default-tabs
        :tabList="tabList"
        :tabIndex="tabIndex"
        theme="blue"
        @changeTab="changeTab"
        class="mt30"
      >
        <div class="panel default-panel kols-select-panel mt20">
          <div class="panel-body">
            <div class="kols-list-container">
              <div v-if="currentList.length > 0">
                <kol-item
                  v-for="item in currentList"
                  :key="item.profile.creation_selected_kol_id"
                  :renderData="item"
                  :checkedIds="kolsCheckedIds"
                  @selectKol="selectKol"
                ></kol-item>
              </div>
              <div v-else class="empty-area text-center">{{$t('lang.noData')}}</div>
            </div>
          </div>
        </div>
      </default-tabs>
    </div>
  </div>
</template>

<script>
import axios from 'axios'
import apiConfig from '@/config'
import commonJs from '@javascripts/common.js'
import DefaultTabs from "@components/DefaultTabs"
import KolItem from '@components/KolItem'
import CreateProcess from './components/CreateProcess'
import StatusArea from './components/StatusArea'
import { mapState } from 'vuex'

export default {
  name: 'ChooseKols',
  components: {
    DefaultTabs,
    CreateProcess,
    StatusArea,
    KolItem
  },
  data () {
    return {
      processStatus: {
        current: 2,
        index: 1
      },
      creationId: this.$route.params.id,
      totalPrice: 0,
      detailData: {},
      tabIndex: 0,
      tabList: [
        {
          index: 0,
          name: 'creations.status.waiting'
        },
        {
          index: 1,
          name: 'creations.status.processing'
        },
        {
          index: 2,
          name: 'creations.status.done'
        }
      ],
      currentList: [],
      kolsCheckedIds: [],
      canSubmit: true
    }
  },
  methods: {
    getDetailData () {
      axios.get(apiConfig.creationsUrl + '/' + this.creationId, {
        headers: {
          'Authorization': this.authorization
        }
      }).then(this.handleGetDetailDataSucc)
    },
    handleGetDetailDataSucc (res) {
      console.log(res)
      let resData = res.data
      if (res.status == 200 && resData) {
        console.log(resData)
        this.detailData = resData
        if (resData.status == 'ended' || resData.status == 'finished' || resData.status == 'closed') {
          this.processStatus.current = 4
          this.processStatus.index = 3
        }
      }
    },
    getTendersData (postUrl) {
      axios.get(postUrl, {
        params: {
          'creation_id': this.creationId
        },
        headers: {
          'Authorization': this.authorization
        }
      }).then(this.handleGetTendersDataSucc)
    },
    handleGetTendersDataSucc (res) {
      let resData = res.data
      // console.log(resData.items)
      this.currentList = resData.items
    },
    changeTab (tab) {
      this.tabIndex = tab.index
      if (tab.index === 0) {
        this.getTendersData(apiConfig.pendingTendersUrl)
        // console.log(this.currentList)
      } else if (tab.index === 1) {
        this.getTendersData(apiConfig.cooperationTendersUrl)
        // console.log(this.currentList)
      } else {
        this.getTendersData(apiConfig.finishedTendersUrl)
        // console.log(this.currentList)
      }
    },
    selectKol (data) {
      console.log(data)
      let _price = parseFloat(data.price)
      let _id = parseInt(data.id)
      let _kolsCheckedIds = this.kolsCheckedIds
      let _index = _kolsCheckedIds.indexOf(_id)
      if (_index == -1) {
        _kolsCheckedIds.push(_id)
        this.totalPrice += _price
      } else {
        _kolsCheckedIds.splice(_index, 1)
        this.totalPrice -= _price
      }
      console.log(_kolsCheckedIds)
    },
    doPay () {
      if (!this.canSubmit) {
        return false
      }
      this.canSubmit = false
      axios.post(apiConfig.payTendersUrl, {
        'creation_id': this.creationId,
        'csk_ary': this.kolsCheckedIds
      }, {
        headers: {
          'Authorization': this.authorization
        }
      }).then(this.handleDoPaySucc)
    },
    handleDoPaySucc (res) {
      let resData = res.data
      console.log(res)
      this.canSubmit = true
      if (res.status == 201) {
        let tenderId = resData.id
        this.$router.push('/creations/'+ this.creationId +'/pay/'+ tenderId)
      }
    }
  },
  mounted () {
    this.getDetailData()
    this.getTendersData(apiConfig.pendingTendersUrl)
  },
  computed: {
    ...mapState(['authorization'])
  }
}
</script>

<style lang="scss" scoped>
.campaign-kols-content {
  padding: 0 100px 30px;
  @include respond-to(mobile) {
    padding: 0 16px 30px;
  }
}
.kols-select-panel {
  .panel-foot {
    padding: 30px;
    .select-statistics {
      height: 32px;
      line-height: 32px;
      .num {
        color: nth($blue, 1);
      }
    }
  }
}
.kols-list-container {
  text-align: left;
  .kol-item {
    border-bottom: 1px solid rgba(0, 0, 0, .1);
    &:last-child {
      border-bottom: none;
    }
  }
}
</style>
