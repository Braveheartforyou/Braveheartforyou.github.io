<template>
  <div class="creation-form">
    <div class="panel default-panel mt20">
      <div class="panel-head">
        <h5 class="title">{{$t('lang.creations.campaignInfo')}}</h5>
      </div>
      <div class="panel-body">
        <div class="form-horizontal campaign-create-form">
          <div class="form-group">
            <div class="col-sm-3 col-xs-12 control-label">{{$t('lang.creations.name.title')}}:</div>
            <div class="col-sm-8 col-xs-12">
              <input
                type="text"
                name="name"
                class="form-control"
                :class="[errors.has('name') ? 'danger' : '']"
                v-model="submitData.name"
                :placeholder="$t('lang.creations.name.placeholder')"
                v-validate="'required'"
              >
              <div
                class="form-tips danger"
                v-show="errors.has('name')"
              >
                {{$t('lang.creations.name.errorTips')}}
              </div>
            </div>
          </div>
          <div class="form-group">
            <div class="col-sm-3 col-xs-12 control-label">{{$t('lang.creations.description.title')}}:</div>
            <div class="col-sm-8 col-xs-12">
              <input
                type="text"
                name="desc"
                class="form-control"
                :class="[errors.has('desc') ? 'danger' : '']"
                v-model="submitData.description"
                :placeholder="$t('lang.creations.description.placeholder')"
                v-validate="'required'"
              >
              <div
                class="form-tips danger"
                v-show="errors.has('desc')"
              >
                {{$t('lang.creations.description.errorTips')}}
              </div>
            </div>
          </div>
          <div class="form-group">
            <div class="col-sm-3 col-xs-12 control-label">{{$t('lang.creations.brandName.title')}}:</div>
            <div class="col-sm-8 col-xs-12">
              <select
                name="brand"
                class="form-control"
                :class="[errors.has('brand') ? 'danger' : '']"
                v-model="submitData.trademark_id"
                v-validate="'required'"
              >
                <option value="">{{$t('lang.creations.brandName.placeholder')}}</option>
                <option
                  v-for="item in brandsList"
                  :key="item.id"
                  :value="item.id"
                >{{item.name}}</option>
              </select>
              <div
                class="form-tips danger"
                v-show="errors.has('brand')"
              >
                {{$t('lang.creations.brandName.errorTips')}}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="panel default-panel mt20">
      <div class="panel-head">
        <h5 class="title">{{$t('lang.creations.campaignInfo')}}</h5>
      </div>
      <div class="panel-body">
        <div class="form-horizontal campaign-create-form">
          <div class="form-group">
            <div class="col-sm-3 col-xs-12 control-label">{{$t('lang.creations.platform.title')}}:</div>
            <div class="col-sm-8 col-xs-12">
              <div class="row">
                <div
                  v-for="(item, index) in terracesList"
                  :key="item.id"
                  class="col-sm-6 col-xs-12 platform-item"
                >
                  <div class="col-sm-2 col-xs-3 pr0 pl0 text-center">
                    <div
                      class="check-icon"
                      :class="[item.checked ? 'checked' : '']"
                      @click="terraceCheck(item.id)"
                    >
                      <img :src="item.avatar" alt="" class="icon-img" />
                      <div class="iconfont icon-check"></div>
                    </div>
                  </div>
                  <div class="col-sm-10 col-xs-9 pr0">
                    <input
                      type="number"
                      :name="'platform' + item.id"
                      class="form-control"
                      :class="[errors.has('platform' + item.id) ? 'danger' : '']"
                      v-model="item.val"
                      :placeholder="$t('lang.creations.platform.placeholder')"
                      v-validate="item.checked ? 'required' : ''"
                    >
                  </div>
                </div>
                <input
                  type="hidden"
                  name="terrace"
                  v-model="submitData.terraces"
                  v-validate="'required'"
                >
              </div>
              <div class="row">
                <div class="col-sm-12">
                  <div
                    class="form-tips text-right danger"
                    v-show="errors.has('terrace')"
                  >
                    {{$t('lang.creations.platform.errorTips')}}
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="form-group">
            <div class="col-sm-3 col-xs-12 col-xs-12 control-label">{{$t('lang.creations.picture.title')}}:</div>
            <div class="col-sm-8 col-xs-12 col-xs-12">
              <div v-if="submitData.img_url != ''" class="upload-imgs-list">
                <div class="upload-img-item">
                  <img :src="submitData.img_url" alt="" class="upload-img" />
                  <div class="iconfont icon-close close-btn" @click="delPhoto"></div>
                </div>
              </div>
              <vue-core-image-upload
                v-else
                :class="['upload-img-btn', 'iconfont', 'icon-image']"
                crop="local"
                crop-ratio="4:3"
                @imageuploaded="imageuploaded"
                @imageuploading="imageuploading"
                inputOfFile="image"
                text=""
                :max-file-size="5242880"
                :compress="80"
                :max-width="400"
                input-accept="image/*"
                :headers="{'Authorization': authorization}"
                :url="uploadImageUrl">
              </vue-core-image-upload>
              <input
                type="hidden"
                name="img_url"
                v-model="submitData.img_url"
                v-validate="'required'"
              >
              <div
                class="form-tips"
                :class="[errors.has('img_url') ? 'danger' : '']"
              >
                {{$t('lang.creations.picture.errorTips')}}
              </div>
            </div>
          </div>
          <div class="form-group">
            <div class="col-sm-3 col-xs-12 control-label">{{$t('lang.creations.time.title')}}:</div>
            <div class="col-sm-8 col-xs-12">
              <datepicker
                name="campaignTime"
                range
                type="datetime"
                lang="en"
                format="YYYY-MM-DD HH:mm:ss"
                input-class="form-control"
                :placeholder="$t('lang.creations.time.placeholder')"
                v-model="campaignTime"
                v-validate="'required'"
                :minute-step="10"
                confirm
              ></datepicker>
              <div
                class="form-tips text-right danger"
                v-show="errors.has('campaignTime')"
              >
                {{$t('lang.creations.time.errorTips')}}
              </div>
            </div>
          </div>
          <div class="form-group">
            <div class="col-sm-3 col-xs-12 control-label">{{$t('lang.creations.kolNumber.title')}}:</div>
            <div class="col-sm-3 col-xs-12">
              <input
                type="number"
                name="kols_count"
                class="form-control"
                :class="[errors.has('kols_count') ? 'danger' : '']"
                v-model.number="submitData.pre_kols_count"
                :placeholder="$t('lang.creations.kolNumber.placeholder')"
                v-validate="'required|number'"
              >
              <div
                class="form-tips danger"
                v-show="errors.has('kols_count')"
              >
                {{$t('lang.creations.kolNumber.errorTips')}}
              </div>
            </div>
            <div class="col-sm-2 col-xs-12 control-label">{{$t('lang.creations.budget.title')}}:</div>
            <div class="col-sm-3 col-xs-12">
              <input
                type="number"
                name="pre_amount"
                class="form-control"
                :class="[errors.has('pre_amount') ? 'danger' : '']"
                v-model.number="submitData.pre_amount"
                :placeholder="$t('lang.creations.budget.placeholder')"
                v-validate="'required|number'"
              >
              <div
                class="form-tips danger"
                v-show="errors.has('pre_amount')"
              >
                {{$t('lang.creations.budget.errorTips')}}
              </div>
            </div>
          </div>
          <div class="form-group">
            <div class="col-sm-3 col-xs-12 control-label">{{$t('lang.creations.precaution.title')}}:</div>
            <div class="col-sm-8 col-xs-12">
              <textarea
                name="notice"
                v-model="submitData.notice"
                class="form-control"
                rows="6"
                :placeholder="$t('lang.creations.precaution.placeholder')"
              ></textarea>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="panel default-panel mt20">
      <div class="panel-head">
        <h5 class="title">{{$t('lang.creations.bigVRequirement')}}</h5>
      </div>
      <div class="panel-body">
        <div class="form-horizontal campaign-create-form">
          <div class="form-group">
            <tags-list
              :renderData="tagsList"
              :checkedIds="checkedIds"
              @checkTag="checkTag"
            ></tags-list>
            <input
              type="hidden"
              name="tags"
              v-model="submitData.target.industries"
              v-validate="'required'"
            >
            <div
              class="form-tips danger"
              v-show="errors.has('tags')"
            >
              {{$t('lang.creations.tags.errorTips')}}
            </div>
          </div>
          <div class="form-group">
            <div class="col-sm-3 col-xs-12 control-label">{{$t('lang.creations.price.title')}}:</div>
            <div class="col-sm-8 col-xs-12">
              <select
                name="price"
                class="form-control"
                :class="[errors.has('price') ? 'danger' : '']"
                v-model="price"
              >
                <option value="0,1000000">{{$t('lang.creations.price.placeholder')}}</option>
                <option value="0,5000">0 - 5,000</option>
                <option value="5000,10000">5,000 - 10,000</option>
                <option value="10000,50000">10,000 - 50,000</option>
                <option value="50000,100000">50,000 - 100,000</option>
                <option value="100000,200000">100,000 - 200,000</option>
                <option value="200000,1000000">200,000 +</option>
              </select>
              <div class="form-tips">
                {{$t('lang.creations.price.errorTips')}}
              </div>
            </div>
          </div>
          <!-- <div class="form-group">
            <div class="col-sm-3 col-xs-12 control-label">{{$t('lang.creations.followerAge.title')}}:</div>
            <div class="col-sm-3 col-xs-12">
              <select class="form-control">
                <option value="全部">{{$t('lang.creations.followerAge.placeholder')}}</option>
                <option value="10,20">10-20 {{$t('lang.yearsOld')}}</option>
                <option value="20,30">20-30 {{$t('lang.yearsOld')}}</option>
                <option value="30,40">30-40 {{$t('lang.yearsOld')}}</option>
                <option value="40,50">40-50 {{$t('lang.yearsOld')}}</option>
                <option value="50,60">50-60 {{$t('lang.yearsOld')}}</option>
                <option value="60,100">60 {{$t('lang.yearsOlder')}}</option>
              </select>
              <div class="form-tips">{{$t('lang.creations.followerAge.errorTips')}}</div>
            </div>
            <div class="col-sm-2 col-xs-12 control-label">{{$t('lang.creations.followerGender.title')}}:</div>
            <div class="col-sm-3 col-xs-12">
              <select class="form-control">
                <option value="全部">{{$t('lang.creations.followerGender.placeholder')}}</option>
                <option value="1">{{$t('lang.male')}}</option>
                <option value="2">{{$t('lang.female')}}</option>
              </select>
              <div class="form-tips">{{$t('lang.creations.followerGender.errorTips')}}</div>
            </div>
          </div>

          <div class="form-group">
            <div class="col-sm-3 col-xs-12 control-label">{{$t('lang.creations.followerDistrict.title')}}:</div>
            <div class="col-sm-8 col-xs-12">
              <div class="row">
                <div class="col-sm-6">
                  <select
                    name="province"
                    class="form-control"
                    v-model="province"
                    @change="changeProvince"
                  >
                    <option value="">{{$t('lang.creations.followerDistrict.provincePlaceholder')}}</option>
                    <option
                      v-for="(item, index) of provinceData"
                      :key="index"
                      :value="item.provinceName"
                    >
                      {{item.provinceName}}
                    </option>
                  </select>
                  <div class="form-tips">{{$t('lang.creations.followerDistrict.provinceErrorTips')}}</div>
                </div>
                <div class="col-sm-6">
                  <select
                    name="city"
                    class="form-control"
                    v-model="city"
                    @change="changeCity"
                  >
                    <option value="">{{$t('lang.creations.followerDistrict.cityPlaceholder')}}</option>
                    <option
                      v-for="(item, index) of cityData"
                      :key="index"
                      :value="item.citysName"
                    >
                      {{item.citysName}}
                    </option>
                  </select>
                  <div class="form-tips">{{$t('lang.creations.followerDistrict.cityErrorTips')}}</div>
                </div>
              </div>
            </div>
            <input
              type="hidden"
              name="region"
              v-model="checkedCitys"
            >
          </div>
          <div class="form-group">
            <div class="col-sm-3 col-xs-12 control-label">{{$t('lang.creations.followerDistrict.title')}}:</div>
            <div class="col-sm-8 col-xs-12">
              <ul v-if="checkedCitys.length > 0" class="city-list">
                <li
                  v-for="(item, index) in checkedCitys"
                  :key="index"
                  class="item"
                >
                  <span
                    class="iconfont icon-close"
                    @click="delCity(item)"
                  ></span>
                  {{item}}
                </li>
              </ul>
              <p v-else class="form-control-static">{{$t('lang.all')}}</p>
            </div>
          </div> -->
          <div class="form-group text-center">
            <button
              type="button"
              class="btn btn-blue btn-outline"
              @click="searchKolsCtrl"
            >{{$t('lang.creations.serchBtn')}}</button>
          </div>
        </div>
      </div>
    </div>

    <div v-if="showKols">
      <div
        v-if="kolsList.length > 0"
        class="row"
      >
        <div class="col-sm-6 col-xs-12 mt20">
          <recommended-panel
            :title="$t('lang.creations.recommendedKOLs')"
            :terracesList="terracesList"
            :kolsList="kolsList"
            :kolsPage="kolsPage"
            :kolsPerPage="kolsPerPage"
            :kolsTotal="kolsTotal"
            :routerData="kolRouterData"
            @checkedKols="checkedKols"
            @changeKolsPage="changeKolsPage"
            @changePlatform="changePlatform"
          ></recommended-panel>
        </div>
        <div class="col-sm-6 col-xs-12 mt20">
          <kols-list-panel
            title="Shopping Cart"
            :kolsList="cartKolsList"
            :kolsPage="kolsCartPage"
            :kolsPerPage="kolsCartPerPage"
            :kolsTotal="kolsCartTotal"
            :routerData="kolRouterData"
            @checkedKols="checkedCartKols"
            @changeKolsPage="changeCartKolsPage"
          ></kols-list-panel>
        </div>
      </div>

      <div v-else class="panel default-panel mt20">
        <div class="panel-body">
          <div class="empty-area text-center">{{$t('lang.creations.kolsNoResult')}}</div>
        </div>
      </div>
    </div>

    <div v-if="submitData.selected_kols.length > 0" class="panel default-panel mt20">
      <div class="panel-head">
        <h5 class="title">{{$t('lang.creations.bigVSelected')}}</h5>
      </div>
      <div class="panel-body">
        <div class="checked-kols-list clearfix">
          <kols-list-item
            v-for="item in submitData.selected_kols"
            :key="item.profile_id"
            :renderStatus="kolRenderStatus"
            :renderData="item"
            :routerData="kolRouterData"
            @handleDelete="delCheckedKol"
          ></kols-list-item>
        </div>
      </div>
    </div>

    <div class="text-center create-btn-area">
      <router-link
        class="btn btn-cyan btn-outline back-btn"
        to="/creations"
      >{{$t('lang.backListBtn')}}</router-link>
      <button
        type="button"
        class="btn btn-cyan next-btn"
        @click="doConfirm"
        :disabled="canSubmit ? false : true"
      >{{$t('lang.submitBtn')}}</button>
    </div>
  </div>
</template>

<script>
import axios from 'axios'
import apiConfig from '@/config'
import commonJs from '@javascripts/common.js'
import cityJs from '@javascripts/cities.js'
import Datepicker from 'vue2-datepicker'
import TagsList from '@components/TagsList'
import KolsListItem from '@components/KolsListItem'
import KolsListPanel from './KolsListPanel'
import RecommendedPanel from './RecommendedPanel'
import VueCoreImageUpload from 'vue-core-image-upload'
import { mapState } from 'vuex'

export default {
  name: 'CreationForm',
  props: {
    formType: String
  },
  components: {
    Datepicker,
    TagsList,
    KolsListItem,
    KolsListPanel,
    RecommendedPanel,
    VueCoreImageUpload
  },
  data () {
    return {
      detailData: {},
      brandsList: [],
      tagsList: [],
      checkedIds: [],
      checkedTags: [],
      terracesList: [],
      kolSearchUrl: '',
      kolsParams: {},
      kolsList: [],
      cartKolsParams: {},
      cartKolsList: [],
      plateformName: '',
      uploadImageUrl: apiConfig.uploadImageUrl,
      loading: false,
      campaignTime: '',
      checkedCitys: [],
      provinceData: [],
      province: '',
      cityData: [],
      city: '',
      price: '0,1000000',
      submitData: {
        name: '',
        description: '',
        trademark_id: '',
        start_at: '',
        end_at: '',
        pre_kols_count: '',
        pre_amount: '',
        img_url: '',
        target: {
          industries: '',
          price_from: '',
          price_to: ''
        },
        terraces: [],
        selected_kols: [],
        notice: ''
      },
      kolsPage: 0,
      kolsPerPage: 4,
      kolsTotal: 0,
      kolsCartPage: 0,
      kolsCartPerPage: 4,
      kolsCartTotal: 0,
      kolRenderStatus: {
        hasLiked: false,
        hasMsg: false,
        hasChecked: false,
        hasInflunce: false,
        hasCart: false,
        hasDelete: true
      },
      kolRouterData: {
        type: '',
        keywords: ''
      },
      showKols: false,
      canSubmit: true
    }
  },
  methods: {
    getBaseData () {
      axios.get(apiConfig.baseInfosUrl, {
        headers: {
          'Authorization': this.authorization
        }
      }).then(this.handleGetBaseDataSucc)
    },
    handleGetBaseDataSucc (res) {
      // console.log(res)
      if (res.status == 200 && res.data) {
        const data = res.data
        this.brandsList = data.trademarks_list
        this.tagsList = data.tags_list

        let _terracesList = data.terraces_list
        _terracesList.forEach(item => {
          item.checked = false
          item.val = ''
        })
        this.terracesList = _terracesList
      }
    },
    getCollectedKolsData () {
      axios.get(apiConfig.kolCollectListUrl, {
        params: this.cartKolsParams,
        headers: {
          'Authorization': this.authorization
        }
      }).then(this.handleGetCollectedKolsDataSucc)
    },
    handleGetCollectedKolsDataSucc (res) {
      // console.log(res)
      if (res.status == 200 && res.data) {
        const resData = res.data
        this.cartKolsList = resData.items
        this.kolsCartTotal = parseInt(resData.paginate['X-Total'])

        let _selectedKols = this.submitData.selected_kols
        if (_selectedKols.length > 0) {
          _selectedKols.forEach(item => {
            this.cartKolsList.forEach(e => {
              if (item.profile_id == e.profile_id) {
                e.checked = true
              }
            })
          })
        }

        // if (this.formType == 'create') {
        //   if (resData.items.length > 0) {
        //     this.cartKolsList.forEach(item => {
        //       item.checked = false
        //     })
        //   }
        // }
        // if (this.formType == 'edit') {
        //   let _selectedKols = this.submitData.selected_kols
        //   console.log(_selectedKols)
        //   _selectedKols.forEach(item => {
        //     this.cartKolsList.forEach(e => {
        //       if (item.profile_id == e.profile_id) {
        //         e.checked = true
        //       }
        //     })
        //   })

        // console.log(this.cartKolsList)
        // }
      }
    },
    getDetailData () {
      axios.get(apiConfig.creationsUrl + '/' + this.$route.params.id, {
        headers: {
          'Authorization': this.authorization
        }
      }).then(this.handleGetDetailDataSucc)
    },
    handleGetDetailDataSucc (res) {
      // console.log(res)
      let resData = res.data
      if (res.status == 200 && resData) {
        // console.log(resData)
        this.detailData = resData
        this.submitData.name = resData.name
        this.submitData.description = resData.description
        this.submitData.trademark_id = resData.trademark_id
        this.submitData.start_at = resData.start_at
        this.submitData.end_at = resData.end_at
        this.submitData.pre_kols_count = resData.pre_kols_count
        this.submitData.pre_amount = resData.pre_amount
        this.submitData.img_url = resData.img_url
        this.submitData.target.industries = resData.targets_hash.industries
        this.submitData.target.price_from = resData.targets_hash.price_from
        this.submitData.target.price_to = resData.targets_hash.price_to
        this.submitData.terraces = resData.terraces
        this.submitData.selected_kols = resData.selected_kols
        this.submitData.notice = resData.notice
        this.campaignTime = []
        this.campaignTime[0] = resData.start_at
        this.campaignTime[1] = resData.end_at
        this.price = resData.targets_hash.price_from + ',' + resData.targets_hash.price_to

        let _terracesList = this.terracesList
        _terracesList.forEach(item => {
          resData.terraces.forEach(e => {
            if (item.id == e.terrace_id) {
              item.checked = true
              item.val = e.exposure_value
            }
          })
        })
        // console.log(_terracesList)

        let _tagsList = this.tagsList
        let _checkedData = resData.targets_hash.industries
        let _checkedArr = _checkedData.split(',')
        let _checkedIds = []
        let _checkedTags = []
        _tagsList.forEach(item => {
          _checkedArr.forEach(e => {
            if (item.name == e) {
              _checkedIds.push(item.id)
              _checkedTags.push(item.name)
            }
          })
        })

        this.checkedTags = _checkedTags
        // console.log(this.checkedTags)
        this.checkedIds = _checkedIds
        // console.log(this.checkedIds)

        // let _citys
        // if (resData.region == '全部') {
        //   this.checkedCitys = []
        // } else {
        //   _citys = resData.region
        //   _citys = _citys.split('/')
        //   _citys.forEach(item => {
        //     this.checkedCitys.push(item)
        //   })
        // }
        // console.log(this.checkedCitys)

        this.searchKolsCtrl()
        this.cartKolsParams.page = this.kolsCartPage + 1
        this.cartKolsParams.per_page = this.kolsCartPerPage
        this.getCollectedKolsData()
        // console.log(this.kolsList)
      }
    },
    searchKols (postUrl) {
      // console.log(postUrl)
      // console.log(this.kolsParams)
      // console.log(this.kolsPage)
      axios.post(postUrl, this.kolsParams, {
        headers: {
          'Authorization': this.authorization
        }
      }).then(this.handleSearchKolsSucc)
    },
    handleSearchKolsSucc (res) {
      // console.log(res)
      let resData = res.data
      // console.log(resData)
      this.kolsList = []
      this.kolsList = resData.data
      this.kolsTotal = resData.total_record_count
      console.log(this.kolsList)
      this.kolsList.forEach(item => {
        switch (this.plateformName) {
          case 'public_wechat_account':
            item.terrace_avatar = 'http://img.robin8.net/wechat.png'
            break
          case 'weibo':
            item.terrace_avatar = 'http://img.robin8.net/weibo.png'
            break
          case 'xiaohongshu':
            item.terrace_avatar = 'http://img.robin8.net/xiaohongshu.png'
            break
          case 'douyin':
            item.terrace_avatar = 'http://img.robin8.net/douyin.png'
            break
          case 'bilibili':
            item.terrace_avatar = 'http://img.robin8.net/bilibili.png'
            break
          case 'kuaishou':
            item.terrace_avatar = 'http://img.robin8.net/kuaishou.png'
            break
          case 'instagram':
            item.terrace_avatar = 'http://img.robin8.net/instagram.png'
            break
          case 'youtube':
            item.terrace_avatar = 'http://img.robin8.net/youtube.png'
            break
          case 'facebook':
            item.terrace_avatar = 'http://img.robin8.net/facebook.png'
            break
          default:
            item.terrace_avatar = ''
        }
      })

      let _selectedKols = this.submitData.selected_kols
      if (_selectedKols.length > 0) {
        _selectedKols.forEach(item => {
          this.kolsList.forEach(e => {
            if (item.profile_id == e.profile_id) {
              e.checked = true
            }
          })
        })
      }

      // if (this.formType == 'create') {
      //   if (resData.data.length > 0) {
      //     this.kolsList.forEach(item => {
      //       item.checked = false
      //     })
      //   }
      // }
      // if (this.formType == 'edit') {
      //   let _selectedKols = this.submitData.selected_kols
      //   _selectedKols.forEach(item => {
      //     this.kolsList.forEach(e => {
      //       if (item.profile_id == e.profile_id) {
      //         e.checked = true
      //       }
      //     })
      //   })
      // }
    },
    searchKolsCtrl () {
      let _brands_list = this.brandsList
      let _checked_trademark_id = this.submitData.trademark_id
      _brands_list.forEach(item => {
        if (_checked_trademark_id == item.id) {
          this.kolRouterData.keywords = item.keywords
        }
      })

      let _startTime = new Date(this.campaignTime[0])
      let _endTime = new Date(this.campaignTime[1])
      _startTime.setHours(_startTime.getHours() + 8)
      _endTime.setHours(_endTime.getHours() + 8)

      let _price = this.price
      _price = _price.split(',')

      this.kolsParams = {
        // start_date: this.submitData.start_at,
        // end_date: this.submitData.start_end,
        start_date: _startTime,
        end_date: _endTime,
        industries: this.checkedTags,
        page_no: this.kolsPage,
        page_size: this.kolsPerPage,
        price_from: _price[0],
        price_to: _price[1]
      }

      // 已选择平台
      // let _terraces = this.submitData.terraces

      // 全部平台
      let _terraces = this.terracesList
      // console.log(_terraces)

      this.kolsList = []
      this.$validator.validateAll().then((msg) => {
        // console.log(msg)
        if (msg) {
          // console.log('验证通过')
          let _firstPlatform = _terraces[0].short_name
          // console.log(_firstPlatform)
          this.checkingPlatform(_firstPlatform)
          // console.log(this.kolSearchUrl)
          this.searchKols(this.kolSearchUrl)
          this.showKols = true

          // if (_terraces.length > 0) {
          //   let _checkedPlatform = _terraces[0].short_name
          //   console.log(_checkedPlatform)
          //   switch (_checkedPlatform) {
          //     case 'public_wechat_account':
          //       this.searchKols(apiConfig.kolWxSearchUrl)
          //       this.plateformName = 'public_wechat_account'
          //       this.kolRouterData.type = '1'
          //       break
          //     case 'weibo':
          //       this.searchKols(apiConfig.kolWbSearchUrl)
          //       this.plateformName = 'weibo'
          //       this.kolRouterData.type = '0'
          //       break
          //     case 'xiaohongshu':
          //       this.searchKols(apiConfig.kolXhsSearchUrl)
          //       this.plateformName = 'xiaohongshu'
          //       this.kolRouterData.type = '2'
          //       break
          //     case 'douyin':
          //       this.searchKols(apiConfig.kolDySearchUrl)
          //       this.plateformName = 'douyin'
          //       this.kolRouterData.type = '5'
          //       break
          //     case 'bilibili':
          //       this.searchKols(apiConfig.kolBlSearchUrl)
          //       this.plateformName = 'bilibili'
          //       this.kolRouterData.type = '4'
          //       break
          //     case 'kuaishou':
          //       this.searchKols(apiConfig.kolKsSearchUrl)
          //       this.plateformName = 'kuaishou'
          //       this.kolRouterData.type = '3'
          //       break
          //     default:
          //       this.searchKols(apiConfig.kolWxSearchUrl)
          //       this.plateformName = 'public_wechat_account'
          //       this.kolRouterData.type = '1'
          //   }
          // } else {
          //   this.searchKols(apiConfig.kolWxSearchUrl)
          //   this.plateformName = 'public_wechat_account'
          //   this.kolRouterData.type = '1'
          // }
        }
      })
    },
    changeKolsPage (data) {
      // console.log(data.page)
      let _plateformName = this.plateformName
      // console.log(_plateformName)
      this.checkingPlatform(_plateformName)
      this.kolsPage = data.page - 1
      // this.searchKolsCtrl()
      this.kolsParams.page_no = data.page - 1
      this.searchKols(this.kolSearchUrl)
    },
    changeCartKolsPage (data) {
      // console.log(data.page)
      this.cartKolsParams.page = data.page
      this.getCollectedKolsData()
    },
    checkedKolsCtrl (id, list) {
      let _id = id
      // console.log(_id)
      let _list = list
      let _checkedKols = this.submitData.selected_kols
      let _kolItem = commonJs.buildObjData('profile_id', _id)

      let result = _checkedKols.some(item => {
        if (item.profile_id == _id) {
          return true
        }
      })

      _list.forEach(item => {
        // console.log(item)
        if (item.profile_id == _id) {
          if (!result) {
            // console.log(this.plateformName)
            // _kolItem.plateform_name = this.plateformName
            _kolItem.plateform_name = !!item.plateform_name && item.plateform_name != '' ? item.plateform_name : this.plateformName
            _kolItem.profile_name = item.profile_name
            _kolItem.avatar_url = item.avatar_url
            _kolItem.description_raw = item.description_raw
            _kolItem.bigv_url = !!item.bigv_url && item.bigv_url != '' ? item.bigv_url : ''
            _kolItem.checked = true
            if (!!item.terrace_avatar && item.terrace_avatar != '') {
              _kolItem.terrace_avatar = item.terrace_avatar
            } else {
              switch (this.plateformName) {
                case 'public_wechat_account':
                  _kolItem.terrace_avatar = 'http://img.robin8.net/wechat.png'
                  break
                case 'weibo':
                  _kolItem.terrace_avatar = 'http://img.robin8.net/weibo.png'
                  break
                case 'xiaohongshu':
                  _kolItem.terrace_avatar = 'http://img.robin8.net/xiaohongshu.png'
                  break
                case 'douyin':
                  _kolItem.terrace_avatar = 'http://img.robin8.net/douyin.png'
                  break
                case 'bilibili':
                  _kolItem.terrace_avatar = 'http://img.robin8.net/bilibili.png'
                  break
                case 'kuaishou':
                  _kolItem.terrace_avatar = 'http://img.robin8.net/kuaishou.png'
                  break
                case 'instagram':
                  _kolItem.terrace_avatar = 'http://img.robin8.net/instagram.png'
                  break
                case 'youtube':
                  _kolItem.terrace_avatar = 'http://img.robin8.net/youtube.png'
                  break
                case 'facebook':
                  _kolItem.terrace_avatar = 'http://img.robin8.net/facebook.png'
                  break
                default:
                  _kolItem.terrace_avatar = ''
              }
            }
            item.checked = true
            _checkedKols.push(_kolItem)
          } else {
            let _index
            _checkedKols.forEach(_item => {
              if (item.profile_id == _item.profile_id) {
                _index = _checkedKols.indexOf(_item)
              }
            })
            _kolItem.checked = false
            item.checked = false
            _checkedKols.splice(_index, 1)
          }
        }
      })
      // console.log(_checkedKols)
      this.submitData.selected_kols = _checkedKols
      // console.log(this.submitData.selected_kols)
    },
    checkedKols (data) {
      let _id = data.id
      // console.log(_id)
      let _kolsList = this.kolsList
      this.checkedKolsCtrl(_id, _kolsList)
      // console.log(this.kolsList)
      // this.searchKolsCtrl()

      let _plateformName = this.plateformName

      // console.log(this.plateformName)
      // console.log(this.kolRouterData.type)
      this.checkingPlatform(_plateformName)
      this.searchKols(this.kolSearchUrl)
      // console.log(this.submitData.selected_kols)
    },
    checkedCartKols (data) {
      let _id = data.id
      // console.log(_id)
      let _cartKolsList = this.cartKolsList
      this.checkedKolsCtrl(_id, _cartKolsList)
      // console.log(this.cartKolsList)
      this.getCollectedKolsData()
      // console.log(this.submitData.selected_kols)
    },
    delCheckedKol (data) {
      let _id = data.id
      // console.log(_id)
      let _checkedKols = this.submitData.selected_kols
      // console.log(_checkedKols)
      let _index
      _checkedKols.forEach(item => {
        if (item.profile_id == _id) {
          _index = _checkedKols.indexOf(item)
          // console.log(_index)
        }
      })
      _checkedKols.splice(_index, 1)
      this.submitData.selected_kols = _checkedKols
      // console.log(this.submitData.selected_kols)
      // this.searchKolsCtrl()

      let _plateformName = this.plateformName
      this.checkingPlatform(_plateformName)
      this.searchKols(this.kolSearchUrl)
      this.getCollectedKolsData()
    },
    changePlatform (data) {
      // console.log(data.platformName)
      this.kolsPage = 0
      this.kolsParams.page_no = 0
      let platformName = data.platformName
      this.checkingPlatform(platformName)
      this.searchKols(this.kolSearchUrl)
    },
    checkingPlatform (platform) {
      switch (platform) {
        case 'public_wechat_account':
          this.kolSearchUrl = apiConfig.kolWxSearchUrl
          this.plateformName = 'public_wechat_account'
          this.kolRouterData.type = '1'
          break
        case 'weibo':
          this.kolSearchUrl = apiConfig.kolWbSearchUrl
          this.plateformName = 'weibo'
          this.kolRouterData.type = '0'
          break
        case 'xiaohongshu':
          this.kolSearchUrl = apiConfig.kolXhsSearchUrl
          this.plateformName = 'xiaohongshu'
          this.kolRouterData.type = '2'
          break
        case 'douyin':
          this.kolSearchUrl = apiConfig.kolDySearchUrl
          this.plateformName = 'douyin'
          this.kolRouterData.type = '5'
          break
        case 'bilibili':
          this.kolSearchUrl = apiConfig.kolBlSearchUrl
          this.plateformName = 'bilibili'
          this.kolRouterData.type = '4'
          break
        case 'kuaishou':
          this.kolSearchUrl = apiConfig.kolKsSearchUrl
          this.plateformName = 'kuaishou'
          this.kolRouterData.type = '3'
          break
        case 'instagram':
          this.kolSearchUrl = apiConfig.kolInsSearchUrl
          this.plateformName = 'instagram'
          this.kolRouterData.type = '6'
          break
        case 'youtube':
          this.kolSearchUrl = apiConfig.kolYoutSearchUrl
          this.plateformName = 'youtube'
          this.kolRouterData.type = '7'
          break
        case 'facebook':
          this.kolSearchUrl = apiConfig.kolFbSearchUrl
          this.plateformName = 'facebook'
          this.kolRouterData.type = '8'
          break
        default:
          this.kolSearchUrl = apiConfig.kolWxSearchUrl
          this.plateformName = 'public_wechat_account'
          this.kolRouterData.type = '1'
      }
    },
    checkTag (data) {
      let _ids = data.ids
      let _tagsList = this.tagsList
      let _checkedTags = []

      _ids.forEach(item => {
        _tagsList.forEach(e => {
          if (e.id == item) {
            _checkedTags.push(e.name)
          }
        })
      })
      // console.log(_checkedTags)
      this.checkedTags = _checkedTags
      this.submitData.target.industries = _checkedTags.toString()
    },
    imageuploaded (res) {
      // console.log(res)
      this.submitData.img_url = res
    },
    imageuploading (res) {
      this.loading = true
    },
    delPhoto () {
      let delConfirm = confirm('确定要删除此图片？')
      if (delConfirm) {
        this.submitData.img_url = ''
      }
    },
    terraceCheck (id) {
      let _terraces = this.submitData.terraces
      let _terracesList = this.terracesList
      let _terraceItem = commonJs.buildObjData('terrace_id', id)
      let result = _terraces.some(item => {
        if (item.terrace_id == id) {
          return true
        }
      })

      _terracesList.forEach(item => {
        if (item.id == _terraceItem.terrace_id) {
          if (!result) {
            _terraceItem.short_name = item.short_name
            _terraces.push(_terraceItem)
            item.checked = true
          } else {
            let _index
            _terraces.forEach(_item => {
              if (item.id == _item.terrace_id) {
                _index = _terraces.indexOf(_item)
              }
            })
            _terraces.splice(_index, 1)
            item.checked = false
          }
        }
      })
      this.submitData.terraces = _terraces
      // console.log(this.submitData.terraces)
    },
    changeProvince (e) {
      const _self = this
      let selectedVal = e.target.value
      // console.log(selectedVal)
      if (selectedVal == '') {
        _self.cityData = []
        _self.city = ''
      }
      this.provinceData.forEach(function (item, index) {
        if (item.provinceName == selectedVal) {
          _self.cityData = item.citys
          // console.log(_self.cityData)
          _self.city = ''
        }
      })
    },
    changeCity (e) {
      const _self = this
      let selectedVal = e.target.value
      let citys = _self.checkedCitys
      // console.log(selectedVal)
      if (selectedVal != '') {
        let _index = citys.indexOf(selectedVal)
        if (_index == -1) {
          citys.push(selectedVal)
        }
        _self.city = ''
      }
      // console.log(_self.checkedCitys)
    },
    delCity (city) {
      let citys = this.checkedCitys
      let _index = citys.indexOf(city)
      if (_index != -1) {
        citys.splice(_index, 1)
      }
      // console.log(this.checkedCitys)
    },
    doSubmit () {
      let _self = this
      let submitParams = {}
      if (_self.formType == 'create') {
        submitParams = {
          'creation': _self.submitData
        }
      }
      if (_self.formType == 'edit') {
        submitParams = {
          'id': _self.$route.params.id,
          'creation': _self.submitData
        }
      }

      if (!_self.canSubmit) {
        return false
      }
      _self.canSubmit = false
      // console.log(submitParams)
      axios.post(apiConfig.creationsUrl, submitParams, {
        headers: {
          'Authorization': _self.authorization
        }
      })
      .then(_self.handleDoSubmitSucc)
      .catch(function(error) {
        // console.log(error)
        alert('提交失败，请重新提交')
        _self.canSubmit = true
      })
    },
    handleDoSubmitSucc (res) {
      // console.log(res)
      if (res.status == 201) {
        let resData = res.data
        // console.log(resData)
        this.$router.push('/creations/' + resData.id)
      } else {
        alert('提交失败，请重新提交')
      }
      this.canSubmit = true
    },
    doConfirm () {
      let _terraces = this.submitData.terraces
      let _terracesList = this.terracesList
      _terraces.forEach(item => {
        // console.log(item)
        _terracesList.forEach(originalItem => {
          if (!!item && item.terrace_id == originalItem.id) {
            item.exposure_value = originalItem.val
          }
        })
      })

      let _startTime = new Date(this.campaignTime[0])
      let _endTime = new Date(this.campaignTime[1])
      _startTime.setHours(_startTime.getHours() + 8)
      _endTime.setHours(_endTime.getHours() + 8)

      this.submitData.start_at = _startTime
      this.submitData.end_at = _endTime

      let _price = this.price
      _price = _price.split(',')
      this.submitData.target.price_from = _price[0]
      this.submitData.target.price_to = _price[1]

      // console.log(this.submitData)

      this.$validator.validateAll().then((msg) => {
        // console.log(msg)
        if (msg) {
          // console.log('验证通过')
          this.doSubmit()
        }
      })
    }
  },
  mounted () {
    if (this.formType == 'edit') {
      let _self = this
      _self.getBaseData()
      setTimeout(function () {
        _self.getDetailData()
      }, 500)
    } else {
      this.getBaseData()
      this.cartKolsParams.page = this.kolsCartPage + 1
      this.cartKolsParams.per_page = this.kolsCartPerPage
      this.getCollectedKolsData()
    }

    this.provinceData = cityJs.citiesData.provinces
  },
  computed: {
    ...mapState(['authorization'])
  }
}
</script>

<style lang="scss" scoped>
.campaign-create-form {
  padding: 10px 0;
  .form-group {
    padding: 10px 40px;
    @include respond-to(mobile) {
      padding: 10px 16px;
    }
  }
  .platform-item {
    margin: 5px 0;
  }
}
.create-btn-area {
  padding: 30px;
  & > .btn {
    width: 150px;
    @include respond-to(mobile) {
      width: auto;
    }
    & + .btn {
      margin-left: 10px;
    }
  }
}
.creation-form {
  padding: 0 100px;
  @include respond-to(mobile) {
    padding: 0 12px;
  }
}
.creation-form /deep/ .kols-list {
  height: 352px;
  padding: 24px 30px;
  font-size: 0;
  @include respond-to(mobile) {
    padding: 10px 20px;
  }
  // & > .kols-list-item {
  //   display: inline-block;
  //   width: 33.33333%;
  //   padding: 0 10px;
  // }
}
.checked-kols-list {
  padding: 24px 30px;
  @include respond-to(mobile) {
    padding: 10px 20px;
  }
  & > .kols-list-item {
    float: left;
    width: 33.33333%;
    padding: 0 10px;
    @include respond-to(mobile) {
      width: 100%;
    }
  }
}
.empty-area {
  padding: 60px 0;
}
.pr0 {
  padding-right: 0;
}
.pl0 {
  padding-left: 0;
}
</style>
