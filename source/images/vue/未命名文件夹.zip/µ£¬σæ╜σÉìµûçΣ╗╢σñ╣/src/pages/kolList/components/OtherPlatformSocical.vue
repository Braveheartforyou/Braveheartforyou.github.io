<!-- detail.vue 中 其他平台social data 表格数据  -->
<template>
  <div>
    <!-- OtherPlatformSocical -->
    <div class="panel default-panel mt20">
      <div class="panel-body prl30">
        <p class="kol-cloumn">{{$t('lang.kolList.detail.otherSocialData.title')}}</p>
        <div class="activity-table">
          <table class="com-brand-table">
            <tr>
              <th>{{$t('lang.kolList.detail.otherSocialData.platform')}}</th>
              <th v-if="Number(type !== 5) && Number(type !== 2)">{{$t('lang.kolList.detail.otherSocialData.gender')}}</th>
              <th>{{$t('lang.kolList.detail.otherSocialData.price')}}</th>
              <th>{{$t('lang.kolList.detail.otherSocialData.followers')}}</th>

              <th v-if="Number(type === 5) || Number(type === 2)">{{$t('lang.kolList.detail.socialData.likes')}}</th>
              <th v-if="Number(type === 5)">{{$t('lang.kolList.detail.socialData.shares')}}</th>
              <th v-if="Number(type === 2)">{{$t('lang.kolList.detail.otherSocialData.collect')}}</th>
              <th v-if="Number(type === 5) || Number(type === 2)">{{$t('lang.kolList.detail.socialData.comments')}}</th>

              <th>{{$t('lang.kolList.detail.otherSocialData.tagsDescription')}}</th>
              <th>{{$t('lang.kolList.detail.socialData.influence')}}</th>
              <th>{{$t('lang.kolList.detail.socialData.trust')}}</th>
            </tr>
            <tr>
              <td>{{otherSocialData.platform}}</td>
              <td v-if="Number(type !== 5) && Number(type !== 2)">{{otherSocialData.gender}}</td>
              <td>{{otherSocialData.price}}</td>
              <td>{{otherSocialData.followers}}</td>

              <td v-if="Number(type === 5) || Number(type === 2)">{{otherSocialData.stats.avg_likes}}</td>
              <td v-if="Number(type === 5)">{{otherSocialData.stats.avg_shares}}</td>
              <td v-if="Number(type === 2)">{{otherSocialData.stats.avg_collects}}</td>
              <td v-if="Number(type === 5) || Number(type === 2)">{{otherSocialData.stats.avg_comments}}</td>

              <td>{{otherSocialData.tagsDescription}}</td>
              <td>{{otherSocialData.stats.avg_post_influences_percentage}}</td>
              <td>Coming Soon</td>
            </tr>
          </table>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios'
import apiConfig from '@/config'
import { mapState } from 'vuex'
import commonJs from '@javascripts/common.js'
export default {
  name: 'OtherPlatformSocical',
  // props: ['socialData'],
  data() {
    return {
      type: 0,
      otherSocialData: {
        platform: "N/A",
        gender: "N/A",
        price: "N/A",
        followers: "N/A",
        tagsDescription: "N/A",
        stats: {
          avg_likes: "N/A",
          avg_shares: "N/A",
          avg_comments: "N/A",
          avg_collects: "N/A",
          avg_post_influences_percentage: "N/A",
        }
      },
    }
  },
  created() {
    this.type = Number(this.$route.query.type)
    let totalParams = {}
    totalParams.profile_id = this.$route.params.id
    if (Number(this.$route.query.type) === 2) {
      // 小红书
      this.kolXiaohongshuSocial(totalParams)
    }
    if (Number(this.$route.query.type) === 3) {
      // kuaishou
      this.kolKuaishouSocial(totalParams)
    }
    if (Number(this.$route.query.type) === 4) {
      // bilibili
      this.kolBilibiliSocial(totalParams)
    }
     if (Number(this.$route.query.type) === 5) {
      // douyin
      this.kolDouyinSocial(totalParams)
    }
     if (Number(this.$route.query.type) === 6) {
      // instagram
      this.kolInstagramSocial(totalParams)
    }
     if (Number(this.$route.query.type) === 7) {
      // youtube
      this.kolYoutubeSocial(totalParams)
    }
     if (Number(this.$route.query.type) === 8) {
      // facebook
      this.kolFacebookSocial(totalParams)
    }
  },
  computed: {
    ...mapState(['authorization'])
  },
  methods: {
    // 将detail。vue 页面传过来的值 渲染到页面上面
    rendering(res) {
      this.otherSocialData.platform = res.data.platform
      this.otherSocialData.gender = res.data.gender
      if (res.data.pricing.ref_price) {
        this.otherSocialData.price =
          "¥ " + commonJs.threeFormatter(res.data.pricing.ref_price, 2)
      }
      if (res.data.fans_number) {
        this.otherSocialData.followers = res.data.fans_number
      }
      if (res.data.tags_description) {
        this.otherSocialData.tagsDescription = res.data.tags_description
      }
      if (res.data.stats.avg_likes) {
        this.otherSocialData.stats.avg_likes = res.data.stats.avg_likes
      }
      if (res.data.stats.avg_shares) {
        this.otherSocialData.stats.avg_shares = res.data.stats.avg_shares
      }
      if (res.data.stats.avg_comments) {
        this.otherSocialData.stats.avg_comments = res.data.stats.avg_comments
      }
      if (res.data.stats.avg_collects) {
        this.otherSocialData.stats.avg_collects = res.data.stats.avg_collects
      }
      if (res.data.stats.avg_post_influences) {
        this.otherSocialData.stats.avg_post_influences_percentage = 
        commonJs.roundTo(res.data.stats.avg_post_influences / 10, 2) + '%'
      }

    },
    // kolXiaohongshuSocial
    kolXiaohongshuSocial(params) {
      const _that = this
      axios
        .post(apiConfig.kolXiaohongshuSocial, params, {
          headers: {
            Authorization: _that.authorization
          }
        })
        .then(function(res) {
          if (res.status === 200) {
            // console.log('kolXiaohongshuSocial', res)
            // 处理数据
            res.data.platform = "Xiaohongshu"
            _that.rendering(res)
          }
        })
        .catch(function(error) {
          // console.log(error)
        })
    },
    // kolKuaishouSocial
    kolKuaishouSocial(params) {
      const _that = this
      axios
        .post(apiConfig.kolKuaishouSocial, params, {
          headers: {
            Authorization: _that.authorization
          }
        })
        .then(function(res) {
          if (res.status === 200) {
            // console.log('kolKuaishouSocial', res)
            // 处理数据
            res.data.platform = "Kuaishou"
            _that.rendering(res)
          }
        })
        .catch(function(error) {
          // console.log(error)
        })
    },
    // kolBilibiliSocial
    kolBilibiliSocial(params) {
      const _that = this
      axios
        .post(apiConfig.kolBilibiliSocial, params, {
          headers: {
            Authorization: _that.authorization
          }
        })
        .then(function(res) {
          if (res.status === 200) {
            // console.log('kolBilibiliSocial', res)
            // 处理数据
            res.data.platform = "Bilibili"
            _that.rendering(res)
          }
        })
        .catch(function(error) {
          // console.log(error)
        })
    },
    // kolDouyinSocial
    kolDouyinSocial(params) {
      const _that = this
      axios
        .post(apiConfig.kolDouyinSocial, params, {
          headers: {
            Authorization: _that.authorization
          }
        })
        .then(function(res) {
          if (res.status === 200) {
            // console.log('kolDouyinSocial', res)
            // 处理数据
            res.data.platform = "Douyin"
            _that.rendering(res)
          }
        })
        .catch(function(error) {
          // console.log(error)
        })
    },
    // kolInstagramSocial
    kolInstagramSocial(params) {
      const _that = this
      axios
        .post(apiConfig.kolInstagramSocial, params, {
          headers: {
            Authorization: _that.authorization
          }
        })
        .then(function(res) {
          if (res.status === 200) {
            // console.log('kolInstagramSocial', res)
            // 处理数据
            res.data.platform = "Instagram"
            _that.rendering(res)
          }
        })
        .catch(function(error) {
          // console.log(error)
        })
    },
    // kolYoutubeSocial
    kolYoutubeSocial(params) {
      const _that = this
      axios
        .post(apiConfig.kolYoutubeSocial, params, {
          headers: {
            Authorization: _that.authorization
          }
        })
        .then(function(res) {
          if (res.status === 200) {
            // console.log('kolYoutubeSocial', res)
            // 处理数据
            res.data.platform = "Youtube"
            _that.rendering(res)
          }
        })
        .catch(function(error) {
          // console.log(error)
        })
    },
    // kolFacebookSocial
    kolFacebookSocial(params) {
      const _that = this
      axios
        .post(apiConfig.kolFacebookSocial, params, {
          headers: {
            Authorization: _that.authorization
          }
        })
        .then(function(res) {
          if (res.status === 200) {
            // console.log('kolFacebookSocial', res)
            // 处理数据
            res.data.platform = "Facebook"
            _that.rendering(res)
          }
        })
        .catch(function(error) {
          // console.log(error)
        })
    },
  }
}
</script>
<style>
</style>