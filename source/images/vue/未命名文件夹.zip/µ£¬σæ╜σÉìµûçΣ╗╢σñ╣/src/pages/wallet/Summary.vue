<template>
  <div class="wallet-container">
    <div class="panel default-panel">
      <div class="panel-body">
        <table class="default-table">
          <thead>
            <tr>
              <th class="text-center">{{$t('lang.wallet.summaryPage.tradeNo')}}</th>
              <th class="text-center">{{$t('lang.wallet.summaryPage.direct')}}</th>
              <th class="text-center">{{$t('lang.wallet.summaryPage.createdAt')}}</th>
              <th class="text-center">{{$t('lang.wallet.summaryPage.credits')}}</th>
              <th class="text-center">{{$t('lang.wallet.summaryPage.availAmount')}}</th>
              <th class="text-center">{{$t('lang.wallet.summaryPage.remark')}}</th>
            </tr>
          </thead>
          <tbody>
            <tr
              v-for="item in dataList"
              :key="item.id"
            >
              <td class="text-center">{{item.trade_no}}</td>
              <td class="text-center">{{item.direct}}</td>
              <td class="text-center">{{item.created_at}}</td>
              <td class="text-center">{{item.credits}}</td>
              <td class="text-center">{{item.avail_amount}}</td>
              <td class="text-center" v-html="item.remark"></td>
            </tr>
          </tbody>
        </table>
      </div>
      <div v-if="dataList.length > 1" class="panel-foot text-center">
        <a-pagination
          :defaultCurrent="page"
          :defaultPageSize="perPage"
          :total="total"
          :hideOnSinglePage="true"
          :size="paginationSize"
          @change="onPageChange"
        />
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios'
import apiConfig from '@/config'
import commonJs from '@javascripts/common.js'
import { mapState } from 'vuex'

export default {
  name: 'Summary',
  data () {
    return {
      params: {},
      dataList: [],
      page: 1,
      perPage: 10,
      total: 0,
      paginationSize: ''
    }
  },
  methods: {
    getTransactionsData () {
      axios.get(apiConfig.transactionsUrl, {
        params: this.params,
        headers: {
          'Authorization': this.authorization
        }
      }).then(this.handleGetTransactionsDataSucc)
    },
    handleGetTransactionsDataSucc (res) {
      let resData = res.data
      if (res.status == 200 && resData) {
        console.log(resData)
        this.dataList = resData.items
        this.total = parseInt(resData.paginate['X-Total'])
      }
    },
    onPageChange (page) {
      this.params.page = page
      console.log(this.params)
      this.getTransactionsData()
    }
  },
  mounted () {
    this.params.page = this.page
    this.params.per_page = this.perPage
    if (commonJs.isMobile()) {
      this.paginationSize = 'small'
    } else {
      this.paginationSize = ''
    }
    this.getTransactionsData()
  },
  computed: {
    ...mapState(['authorization'])
  }
}
</script>

<style lang="scss" scoped>
.wallet-container {
  padding: 30px 100px;
  @include respond-to(mobile) {
    padding: 16px;
  }
  .panel-body {
    @include respond-to(mobile) {
      overflow-x: auto;
      .default-table {
        max-width: none;
        min-width: 200%;
      }
    }
  }
}
</style>
