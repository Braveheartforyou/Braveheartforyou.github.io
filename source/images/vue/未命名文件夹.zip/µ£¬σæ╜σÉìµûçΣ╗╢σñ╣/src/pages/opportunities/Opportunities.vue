<template>
  <div class="campaign-container">
    <container-header></container-header>
    <router-view></router-view>
  </div>
</template>

<script>
import ContainerHeader from '@/pages/campaigns/components/ContainerHeader'

export default {
  name: 'OpportunityIndex',
  components: {
    ContainerHeader
  },
  data () {
    return {
    }
  }
}
</script>

<style lang="scss" scoped>
</style>