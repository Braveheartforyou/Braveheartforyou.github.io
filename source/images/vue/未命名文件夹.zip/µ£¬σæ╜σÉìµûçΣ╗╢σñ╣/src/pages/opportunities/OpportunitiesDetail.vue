<template>
<div>
  <div class="Kolo-container">
    <div class="panel default-panel kolo-list mt20" v-if="!isContent">
      <div class="panel-body p30">
        <div class="nonetip" v-if="isShow">
          <span>{{$t('lang.koloDetailVue.totalNoDataTip')}}</span>
        </div>
        <div class="r8-loading" v-if="isLoading">
          <a-spin tip="Loading..."/>
        </div>
      </div>
    </div>
    <div v-if="isContent">
      <div class="row">
        <div class="col-lg-3 col-xs-12">
          <div class="panel default-panel mt20">
            <div class="panel-body prl30">
              <div class="kolo-detail media">
                <div class="media-left media-middle">
                  <div class="kolo-img-box-two">
                    <img :src="DataList.avatar_url" alt="">
                  </div>
                </div>
                <div class="media-body media-middle">
                  <h5 class="name">{{DataList.name}}</h5>
                  <p class="dec">{{DataList.desc}}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-9 col-xs-12">
          <div class="panel default-panel mt20">
            <div class="panel-body kolo-detail-platform-box">
              <div class="media p30 kolo-detail-platform">
                <div class="media-left media-middle">
                  <p class="kolo-platform-left">{{$t('lang.koloDetailVue.platform')}}：</p>
                </div>
                <div class="media-body kolo-platform-box-box">
                  <div class="row" v-if="DataList.social_accounts.length > 0">
                    <div class="col-lg-4 col-xs-6 kolo-platform-box" v-for="(item, indexOne) in DataList.social_accounts" :key="indexOne">
                      <div class="media kolo-platform-right">
                        <div class="media-left media-middle">
                          <img :src="item.terrace_avatar_url" alt="">
                        </div>
                        <div class="media-body media-middle">
                          <h5>ID: {{item.username}}</h5>
                          <!-- <span></span> -->
                          <p>{{$t('lang.koloDetailVue.fansNubmer')}}: {{item.followers_count}}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div v-else>
                    <span>{{$t('lang.totalNoDataTip')}}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-12 col-xs-12">
          <div class="panel default-panel mt20">
            <div class="panel-body p30">
              <!-- <p><span>已经沟通品牌:</span>{{DataList.name}}</p> -->
              <p class="text-right home-post-collect">
                <span @click="koloInteresed(DataList)" v-if="!DataList.is_interested"><i class="iconfont icon-star-fill"></i>&nbsp;{{$t('lang.opportunitiesVue.colect')}}</span>
                <span v-else @click="koloUnInteresed(DataList)"  class="kolo-interested-active"><i class="iconfont icon-star-fill active"></i>&nbsp;{{$t('lang.opportunitiesVue.colect')}}</span>
              </p>
              <p class="kolo-detail-title">
                <span>{{$t('lang.koloDetailVue.cooperateTheme')}}:</span>
                <b>{{DataList.title}}</b>
              </p> 
              <p class="kolo-detail-title mt20"><span>{{$t('lang.koloDetailVue.cooperateIntroduce')}}:</span></p> 
              <p class="kolo-detail-dec">{{DataList.description}}</p>
              <p class="kolo-detail-title mt20"><span>{{$t('lang.koloDetailVue.cooperateTime')}}:</span>{{DataList.time_range}}</p>
              <div class="media mt20">
                <div class="media-left media-middle">
                  <p class="kolo-detail-title"><span>{{$t('lang.opportunitiesVue.interested')}}:</span></p>
                </div>
                <div class="media-body media-middle">
                  <div class="row">
                    <div v-for="(item, indexOne)  in DataList.interested_users" :key="indexOne" class="kolo-top-intrested mb10">
                      <img :src='item' alt="">
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="panel default-panel mt20" v-if="isContent">
        <!-- <div class="panel-head">
          <h5 class="title">Comments</h5>
        </div> -->
        <div class="panel-body p30">
          <div class="mb20" v-for="(item, indexOne) in DataList.comments" :key="indexOne">
            <div class="media kolo-first-comment" v-if="item.showCurrentComment">
              <div class="media-left">
                <div class="kolo-first-comment-img">
                  <img :src="item.resource_from_avatar_url" alt="" v-if="item.showCurrentImgUrl">
                  <!-- <img :src="url" alt=""> -->
                </div>
              </div>
              <div class="media-body media-middle">
                <p class="kolo-comment-name">
                  <strong v-if="item.showCurrentImgUrl">{{item.resource_from_name}}:</strong> 
                   <strong v-else>{{$t('lang.koloDetailVue.anonymity')}}:</strong>
                  <span>{{item.content}}</span>
                </p>
                <p class="kolo-time">{{item.created_at}} 
                  <span v-if="!item.showContent" class="kolo-comment-btn" @click="showInputMoudle(item, indexOne)">{{$t('lang.koloCommentBack')}}</span>
                  <span v-else class="kolo-comment-btn" @click="showInputMoudle(item, indexOne)">{{$t('lang.koloCommentBackDel')}}</span>
                </p>
                
                <div v-if="item.showContent">
                  <textarea
                    type="text"
                    class="form-control mt10"
                    :name="'name_' + indexOne"
                    :class="[errors.has('name_' + indexOne) ? 'danger' : '']"
                    v-validate="'required'"
                    v-model="item.inputMoudle"
                    :placeholder="'@' + item.resource_from_name"
                    v-if="item.showCurrentImgUrl"
                  />
                  <textarea
                    type="text"
                    class="form-control mt10"
                    :name="'name_' + indexOne"
                    :class="[errors.has('name_' + indexOne) ? 'danger' : '']"
                    v-validate="'required'"
                    v-model="item.inputMoudle"
                    placeholder=""
                    v-else
                  />
                  <div class="mt10">
                    <div class="kol-select-platform" v-for="platform in item.messageType" :key='platform.tabIndex'>
                      <label class="ctrl-label">
                        <input
                          :name="indexOne + 'fistPlatform'"
                          type="radio"
                          :value="platform.index"
                          v-model="item.inputMessageType"
                          v-validate="'required'"
                          @change="platformFirstChange(item)"
                        />
                        <span>
                          {{$t(`lang.${platform.name}`)}}</span>
                      </label>
                    </div>
                  </div>
                  <div class="text-right">
                    <button
                      type="button"
                      class="btn btn-cyan btn-outline"
                      @click="reply(item, indexOne)"
                    >
                      {{$t('lang.koloComment')}}
                    </button>
                  </div>
                </div>
              </div>
            </div>
            <!-- 循环子评论人 -->
            <div v-for="(keys, indexTwo) in item.replies" :key="indexTwo">
              <div class="media kolo-second-comment"  v-if="keys.showCurrentComment">
                <div class="media-left">
                  <div class="kolo-first-comment-img">
                    <img :src="keys.resource_from_avatar_url" alt="" v-if="keys.showCurrentImgUrl">
                    <!-- <img :src="url" alt=""> -->
                  </div>
                </div>
                <div class="media-body media-middle">
                  <p>
                    <p class="kolo-comment-name">
                      <strong v-if="keys.showCurrentImgUrl">{{keys.resource_from_name}}:</strong>
                    <strong v-else>{{$t('lang.koloDetailVue.anonymity')}}:</strong>
                      <span>{{keys.content}}</span>
                  </p>
                  <p>{{keys.created_at}} 
                    <span v-if="!keys.showContent" class="kolo-comment-btn" @click="showSecondInput(keys, indexOne , indexTwo)">{{$t('lang.koloCommentBack')}}</span>
                    <span v-else class="kolo-comment-btn" @click="showSecondInput(keys, indexOne , indexTwo)">{{$t('lang.koloCommentBackDel')}}</span>
                  </p>
                  <div v-if="keys.showContent">
                    <textarea
                      type="text"
                      :name="'name_' + indexOne + indexTwo"
                      class="form-control mt10"
                      :class="[errors.has('name_' + indexOne + indexTwo) ? 'danger' : '']"
                      v-model="keys.inputMoudle"
                      :placeholder="'@' + keys.resource_from_name"
                      v-validate="'required'"
                      v-if="keys.showCurrentImgUrl"
                    />
                    <textarea
                      type="text"
                      :name="'name_' + indexOne + indexTwo"
                      class="form-control mt10"
                      :class="[errors.has('name_' + indexOne + indexTwo) ? 'danger' : '']"
                      v-model="keys.inputMoudle"
                      placeholder=""
                      v-validate="'required'"
                      v-else
                    />
                    <div class="mt10">
                      <div class="kol-select-platform" v-for="platform in keys.messageType" :key='platform.tabIndex'>
                        <label class="ctrl-label">
                          <input
                            :name="indexTwo + 'secondPlatform'"
                            type="radio"
                            :value="platform.index"
                            v-model="keys.inputMessageType"
                            v-validate="'required'"
                            @change="platformSecondChange(keys)"
                          />
                          <span>
                            {{$t(`lang.${platform.name}`)}}</span>
                        </label>
                      </div>
                    </div>
                    <div class="text-right">
                      <button
                        type="button"
                        class="btn btn-cyan btn-outline"
                        @click="secondReply(keys, indexOne , indexTwo, item)"
                      >
                        {{$t('lang.koloComment')}}
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="media kolo-mine-comment">
            <div class="media-left">
              <div class="kolo-first-comment-img">
                <img :src="avatarImgUrl" alt="">
              </div>
            </div>
            <div class="media-body media-middle">
              <!-- <textarea
                type="text"
                class="form-control mt10"
                name="name"
                :class="[errors.has('name') ? 'danger' : '']"
                v-model="mineContent"
                placeholder="I want to say..."
                v-validate="'required'"
              /> -->
              <textarea
                type="text"
                class="form-control mt10"
                name="name"
                v-model="mineContent"
                placeholder="I want to say..."
              />
              <p class="kolo-wrong-tip" v-if="isTip">{{$t(`lang.koloDetailVue.blankTip`)}}</p>
              <div class="mt10">
                <div class="kol-select-platform" v-for="platform in tabList" :key='platform.tabIndex'>
                  <label class="ctrl-label">
                    <input
                      name="platform"
                      type="radio"
                      :value="platform.index"
                      v-model="selectPlatform"
                      @change="platformChange"
                    />
                    <span>
                      {{$t(`lang.${platform.name}`)}}</span>
                  </label>
                </div>
              </div>
              <div class="text-right">
                <button
                  type="button"
                  class="btn btn-cyan btn-outline"
                  @click="commitComment"
                >
                  {{$t('lang.koloComment')}}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</template>

<script>
import axios from 'axios'
import apiConfig from '@/config'
import store from '@/store'
import commonJs from '@javascripts/common.js'
import { mapState, mapMutations } from 'vuex'
import ContainerHeader from '@/pages/campaigns/components/ContainerHeader'

export default {
  name: 'KoloDetail',
  components: {
    ContainerHeader
  },
  data() {
    return {
      tip: 'koloDetailVue.public',
      isTip: false,
      isLoading: true,
      isShow: false,
      isContent: false,
      DataList: {},
      url: "https://tvax1.sinaimg.cn/crop.0.0.1125.1125.50/67bdce34ly8fvbaxuqvnij20v90v9ju0.jpg",
      mineContent: '',
      selectPlatform: 0,
      tabList: [
        {
          index: 0,
          name: "koloDetailVue.public"
        },
        {
          index: 1,
          name: "koloDetailVue.anonymity"
        },
        {
          index: 2,
          name: "koloDetailVue.justMe"
        }
      ],
    };
  },
  // watch: {
  //   mineContent: {
  //     handler() {
  //       if (this.mineContent !== '') {
  //         this.isTip = false
  //       } else {
  //         this.isTip = true
  //       }
  //     }
  //   }
  // },
  created () {
    // 调用详情的列表
    this.getKoloList(this.$route.params.id)
  },
  computed: {
    ...mapState(['authorization', 'nameStatus', 'avatarImgUrl'])
  },
  methods: {
    // detial list
    getKoloList(id) {
      const _that = this;
      // console.log(this.authorization);
      // console.log('avatarImgUrl' , this.avatarImgUrl)
      axios.get(apiConfig.koloList + '/' + id, {
        headers: {
          'Authorization': this.authorization
        }
      }).then(function(res) {
        if (res.status === 200) {
          let resData = res.data
          // console.log('opportunities 8888', res)
          if (!resData.detail) {
            _that.isShow = false
            _that.isLoading = false
            _that.isContent = true
            _that.DataList = resData
            _that.DataList.comments.forEach((item, index) => {
              item.showContent = false
              item.inputMoudle = '',
              item.inputMessageType = 0,
              item.messageType = [
                {
                  index: 0,
                  name: "koloDetailVue.public"
                },
                {
                  index: 1,
                  name: "koloDetailVue.anonymity"
                },
                {
                  index: 2,
                  name: "koloDetailVue.justMe"
                }
              ]
              // 判断 当前的评论者是不是 当签登陆的人
              if (Number(item.resource_from_id) === Number(_that.nameStatus)) {
                // 相等
                item.showCurrentImgUrl = true
                item.showCurrentComment = true
              } else {
                // item.showCurrentImgUrl = false
                if (item.power === 'none') {
                  item.showCurrentImgUrl = true
                  item.showCurrentComment = true
                } 
                if (item.power === 'anonymity')  {
                  
                  item.showCurrentImgUrl = false
                  item.showCurrentComment = true
                }
                if (item.power === 'justMe')  {
                  item.showCurrentImgUrl = false
                  item.showCurrentComment = false
                }
              }
              item.replies.forEach((key, indexOne) => {
                key.showContent = false
                key.inputMoudle = '',
                key.inputMessageType = 0,
                key.messageType = [
                  {
                    index: 0,
                    name: "koloDetailVue.public"
                  },
                  {
                    index: 1,
                    name: "koloDetailVue.anonymity"
                  },
                  {
                    index: 2,
                    name: "koloDetailVue.justMe"
                  }
                ]
                // 判断 当前的评论者是不是 当签登陆的人
                if (Number(key.resource_from_id) === Number(_that.nameStatus)) {
                  // 相等
                  key.showCurrentImgUrl = true
                  key.showCurrentComment = true
                } else {
                  // item.showCurrentImgUrl = false
                  if (key.power === 'none') {
                    key.showCurrentImgUrl = true
                    key.showCurrentComment = true
                  } 
                  if (key.power === 'anonymity')  {
                    
                    key.showCurrentImgUrl = false
                    key.showCurrentComment = true
                  }
                  if (key.power === 'justMe')  {
                    key.showCurrentImgUrl = false
                    key.showCurrentComment = false
                  }
                }
              })
            })
            // console.log('opportunities 9999', _that.DataList)
          } else {
            _that.isShow = true
            _that.isLoading = false
            _that.isContent = false
          }
        }
      })
    },
    // commend 接口
    commitCommentJog(params, num) {
      const _that = this;
      // console.log(this.authorization);
      axios.post(apiConfig.koloList + '/' + this.$route.params.id + '/comment', params, {
        headers: {
          'Authorization': this.authorization
        }
      }).then(function(res) {
        if (res.status === 201) {
          // console.log('woshi pingun chdenggon ', res)
          if (num) {
            _that.mineContent = ''
            _that.isTip = false
          }
          // 调用详情的列表
          _that.getKoloList(_that.$route.params.id)
        }
      }).catch(function(error) {
        console.log(error)
      })
    },
    platformChange() {
      let tab = this.selectPlatform
    },
    commitComment() {
      // console.log(this.mineContent)
      const _that = this
      let params = {
        content: this.mineContent
      }
      if (Number(this.selectPlatform) === 0) {
        params.power = 'none'
      }
      if (Number(this.selectPlatform) === 1) {
        params.power = 'anonymity'
      }
      if (Number(this.selectPlatform) === 2) {
        params.power = 'just_me'
      }
      if (this.mineContent === '') {
        this.isTip = true
      } else {
        this.isTip = false
        _that.commitCommentJog(params, 1)
      }
      // this.$validator.validate('name').then((msg) => {
      //   if (msg) {
      //     _that.commitCommentJog(params, 1)
      //   }
      // })
    },
    reply(item, currentIndex) {
      const _that = this
      let validateScope = 'name_' + currentIndex
      // console.log('woshi item ', item.inputMoudle, item.id, item.inputMessageType)
      let params = {
        content: item.inputMoudle,
        parent_id: item.id
      }
      if (Number(item.inputMessageType) === 0) {
        params.power = 'none'
      }
      if (Number(item.inputMessageType) === 1) {
        params.power = 'anonymity'
      }
      if (Number(item.inputMessageType) === 2) {
        params.power = 'just_me'
      }
      this.$validator.validate(validateScope).then((msg) => {
        if (msg) {
          _that.commitCommentJog(params)
        }
      })
    },
    showInputMoudle(item, currentIndex) {
      if (item.showContent === false) {
        item.showContent = true
      } else {
        item.showContent = false
      }
      // if (item.id === )
      // this.DataList.comments.forEach(element => {
      //   if (element.id === item.id) {
      //     // if (element.showContent === false) {
      //     //   element.showContent = true
      //     //   // item.showContent = true
      //     // } else {
      //     //   element.showContent = false
      //     //   // item.showContent = false
      //     // }
      //     element.showContent = true
      //   } else {
      //     element.showContent = false
      //   }
      // });
      this.$set(this.DataList.comments, currentIndex, item)
    },
    platformFirstChange(item) {
      
    },
    secondReply(item, currentIndexOne, currentIndexTwo, itemParents) {
      const _that = this
      let validateScope = 'name_' + currentIndexOne + currentIndexTwo
      // console.log(validateScope)
      // console.log('woshi item 445', item.inputMoudle, currentIndexOne, currentIndexTwo)
      let params = {
        content: item.inputMoudle,
        parent_id: itemParents.id
      }
      if (Number(item.inputMessageType) === 0) {
        params.power = 'none'
      }
      if (Number(item.inputMessageType) === 1) {
        params.power = 'anonymity'
      }
      if (Number(item.inputMessageType) === 2) {
        params.power = 'just_me'
      }
      this.$validator.validate(validateScope).then((msg) => {
        if (msg) {
          _that.commitCommentJog(params)
        }
      })
    },
    showSecondInput(item, currentIndexOne, currentIndexTwo) {
      if (item.showContent === false) {
        item.showContent = true
      } else {
        item.showContent = false
      }
      // this.DataList.comments[currentIndexOne].replies[currentIndexTwo] = JSON.parse(JSON.stringify(this.DataList.comments[currentIndexOne].replies[currentIndexTwo]))
      // this.DataList = newItem
      this.$set(this.DataList.comments[currentIndexOne].replies, currentIndexTwo, item)
    },
    platformSecondChange(item) {

    },
    //  感兴趣事件的接口
    koloInteresedPost(id, params) {
      const _that = this
      axios.post(apiConfig.koloList + '/' + id + '/interested', params, {
        headers: {
          'Authorization': this.authorization
        }
      }).then(function(res) {
        // console.log('res collect', res)
        _that.DataList.is_interested = res.data.is_interested
      }).catch(function(error) {
        // console.log(error)
      })
    },
    //  不感兴趣事件的接口
    koloUnInteresedPost(id, params) {
      const _that = this
      axios.post(apiConfig.koloList + '/' + id + '/unterested', params, {
        headers: {
          'Authorization': this.authorization
        }
      }).then(function(res) {
        // console.log('delet res collect', res)
        _that.DataList.is_interested = res.data.is_interested
      }).catch(function(error) {
        // console.log(error)
      })
    },
    // 感兴趣 事件
    koloInteresed(item) {
      this.koloInteresedPost(item.id)
    },
    // 不敢兴趣事件
    koloUnInteresed(item) {
      this.koloUnInteresedPost(item.id)
    },
    // commentInput() {
    //   console.log(90)
    //   if (this.mineContent === "" ) {
    //     this.isTip = true
    //   } else {
    //     this.isTip = false
    //   }
    // }
  }
}
</script>
<style lang="scss" scoped>
.home-post-title {
  @include limit-line(1);
  font-size: $font-nm-s;
  color: nth($text-color, 2);
}
.home-post-content{
  @include limit-line(3);
  font-size: $font-nm-s;
  margin-top: 10px;
}
.kolo-detail{
  height: 109px;
  .name{
    @include limit-line(1);
    margin: 5px 0px 3px;
    font-size: $font-nm-l;
  }
  .dec{
    word-break: break-all;
    @include limit-line(3);

  }
}
// .form-control.danger {
//     border-color: #ecd1d1;
//     color: #cc5353;
//     background-color: #f5dfdf;
// }
.kolo-wrong-tip{
  margin-top: 5px;
  color: nth($red, 2);
  text-align: right;
}
</style>
