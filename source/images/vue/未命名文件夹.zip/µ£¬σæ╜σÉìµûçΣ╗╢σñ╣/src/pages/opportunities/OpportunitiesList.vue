<template>
  <div>
    <div class="Kolo-container">
      <div class="panel default-panel">
        <div class="panel-body p30">
          <!-- 头部搜索框 -->
          <div class="form-horizontal">
            <div class="form-group">
              <div class="col-lg-8 col-xs-8">
                <input
                  type="text"
                  class="form-control"
                  :placeholder="$t('lang.kolList.search.keyword')"
                  v-model="keyword"
                />
              </div>
              <div class="col-lg-4 col-xs-4">
                <button
                    type="button"
                    class="btn btn-cyan btn-outline"
                    @click="search"
                  >{{$t('lang.kolList.search.search')}}</button>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="panel default-panel kolo-list mt20">
        <div class="panel-head">
          <p class="kolo-tit-tip">{{$t('lang.opportunitiesVue.topTip')}}</p>
        </div>
        <div class="panel-body p30">
          <div class="nonetip" v-if="isShow">
            <span>{{$t('lang.totalNoDataTip')}}</span>
          </div>
          <div class="r8-loading" v-if="isLoading">
            <a-spin tip="Loading..."/>
          </div>
          <div v-if="isContent">
            <div class="home-post" v-for="(item, index) in itemList" :key='index'>
              <div class="media mt10">
                <div class="media-left mr10 media-middle">
                  <router-link
                    :to="'/opportunities/' + item.id"
                    target="_blank"
                  >
                    <div class="kolo-img-box">
                      <img :src="item.avatar_url" alt="">
                    </div>
                    <h5 class="text-center mt10">{{item.name}}</h5>
                  </router-link>
                </div>
                <div class="media-body media-middle">
                  <!-- <router-link
                    :to="'/opportunities/' + item.id"
                  >
                    <h5 class="title mb5">{{item.name}}</h5>
                  </router-link> -->
                  <div class="row">
                    <router-link
                    :to="'/opportunities/' + item.id"
                    target="_blank"
                    >
                      <p class="home-post-title col-sm-10" v-html="item.title"></p>
                    </router-link>
                    <!-- <p class="text-right home-post-collect col-sm-2">
                      <span @click="koloInteresed(item)" v-if="!item.is_interested"><i class="iconfont icon-star-fill"></i>&nbsp;{{$t('lang.opportunitiesVue.colect')}}</span>
                      <span v-else @click="koloUnInteresed(item)"  class="kolo-interested-active"><i class="iconfont icon-star-fill active"></i>&nbsp;{{$t('lang.opportunitiesVue.colect')}}</span>
                    </p> -->
                  </div>
                  <p class="desc kolo-desc" v-html="item.description"></p>
                  <p class="desc mt10">
                    <strong>{{$t('lang.opportunitiesVue.time')}}:</strong> {{item.time_range}}&nbsp;&nbsp;
                    <!-- <strong>{{$t('lang.opportunitiesVue.platform')}}:</strong> {{item.platform}} &nbsp;&nbsp;  -->
                    <strong>{{$t('lang.opportunitiesVue.interested')}}:</strong> {{item.interested_count}} &nbsp;&nbsp;
                    <!-- {{$t('lang.opportunitiesVue.joined')}}: {{item.joined}} -->
                    
                  </p>
                  <div class="media mt10">
                    <div class="media-left media-middle" v-if="item.social_accounts.length > 0">
                      <strong>{{$t('lang.opportunitiesVue.OnlyPlatform')}}:</strong>
                    </div>
                    <div class="media-body media-middle">
                      <div class="row">
                        <div v-for="(keys, indexOne)  in item.social_accounts" :key="indexOne" class="kolo-list-platform">
                          <img :src='keys.terrace_avatar_url' alt="">
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="panel-foot text-center"  v-if="isContent">
          <a-pagination
            :defaultCurrent="page"
            :defaultPageSize="perPage"
            :total="total"
            :hideOnSinglePage="true"
            :size="paginationSize"
            @change="onPageChange"
          />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios'
import apiConfig from '@/config'
import store from '@/store'
import commonJs from '@javascripts/common.js'
import { mapState, mapMutations } from 'vuex'
import ContainerHeader from '@/pages/campaigns/components/ContainerHeader'
import API from '@/api'

export default {
  name: 'opportunitiesList',
  components: {
    ContainerHeader
  },
  data() {
    return {
      keyword: '',
      isShow: false,
      isContent: false,
      isLoading: true,
      page: 1,
      perPage: 10,
      total: 0,
      paginationSize: '',
      totalParams: {
        page: 1,
        // pageSize: 10,
      },
      itemList: [
        // {
        //  title: '哪位仙女可以对一场粉色派对say no？又是哪个大牌如此懂得时髦女孩们对于粉色的热' ,
        //  imgUrl: 'https://tvax1.sinaimg.cn/crop.0.0.1125.1125.50/67bdce34ly8fvbaxuqvnij20v90v9ju0.jpg',
        //  name: '妙琳Yukiki',
        //  time: '2019-02-28T20:15:03',
        //  platform: '微博',
        //  interested: 10,
        //  joined: 78
        // }
      ]
    };
  },
  created () {
    if (commonJs.isMobile()) {
      this.paginationSize = 'small'
    } else {
      this.paginationSize = ''
    }
    this.getKoloList(this.totalParams)
  },
  computed: {
    ...mapState(['authorization'])
  },
  methods: {
    getKoloList(totalParams) {
      // // // API.BoutiqueBasedata.getBoutiqueInfo(params).then(res => {})
      console.log(typeof(API.koloList))
      // console.log(API.koloList)
      // API.koloList()
      // API.koloList().then(res => {
      //   console.log('',)
      // })
      console.log(API.koloList)
    },
    // kolo list
    // getKoloList(totalParams) {
    //   const _that = this;
    //   // console.log(this.authorization);
    //   axios.get(apiConfig.koloList, {
    //     params: totalParams,
    //     headers: {
    //       'Authorization': this.authorization
    //     }
    //   }).then(function(res) {
    //     if (res.status === 200) {
    //       let resData = res.data
    //       // console.log('opportunities', res)
    //       if (resData.items.length > 0) {
    //         _that.isShow = false
    //         _that.isLoading = false
    //         _that.isContent = true
    //         _that.total = parseInt(resData.paginate['X-Total'])
    //         _that.itemList = resData.items
    //       } else {
    //         _that.isShow = true
    //         _that.isLoading = false
    //         _that.isContent = false
    //       }
    //     }
    //   })
    // },
    //  感兴趣事件的接口
    koloInteresedPost(id, params) {
      const _that = this
      axios.post(apiConfig.koloList + '/' + id + '/interested', params, {
        headers: {
          'Authorization': this.authorization
        }
      }).then(function(res) {
        // console.log('res collect', res)
        _that.getKoloList(_that.totalParams)
      }).catch(function(error) {
        // console.log(error)
      })
    },
    //  不感兴趣事件的接口
    koloUnInteresedPost(id, params) {
      const _that = this
      axios.post(apiConfig.koloList + '/' + id + '/unterested', params, {
        headers: {
          'Authorization': this.authorization
        }
      }).then(function(res) {
        // console.log('delet res collect', res)
        _that.getKoloList(_that.totalParams)
      }).catch(function(error) {
        // console.log(error)
      })
    },
    // 点击分页
    onPageChange(page) {
      this.isLoading = true
      this.isShow = false
      this.isContent = false
      this.totalParams.page = page
      this.itemList = []
      this.getKoloList(this.totalParams)
    },
    // 感兴趣 事件
    koloInteresed(item) {
      this.koloInteresedPost(item.id)
    },
    // 不敢兴趣事件
    koloUnInteresed(item) {
      this.koloUnInteresedPost(item.id)
    },
    // 头部搜索事件
    search() {
      let params = {
        page: 1,
        search: this.keyword
      }
      this.getKoloList(params)
    }
  }
}
</script>
<style lang="scss" scoped>
.kolo-list{
  .home-post{
    border-bottom: 2px solid $border;
    padding-bottom: 10px;
    &:last-child {
      border-bottom: 0px;
      padding-bottom: 0px;
    }
  }
}
.home-post-title {
  @include limit-line(1);
  font-size: $font-lg-s;
  color: nth($text-color, 2);
  margin-bottom: 10px;
  &:hover{
    color: nth($blue, 3)
  }
}
.kolo-desc{
  word-break: break-all;
}
</style>
