<template>
  <div class="panel default-panel home-top-post">
    <div class="panel-head">
      <h5 class="title">{{$t('lang.homePage.recommend.title')}}</h5>
    </div>

    <default-tabs :tabList="tabList" :tabIndex="tabIndex" @changeTab="changeTab">
      <div class="panel-body list-content">
        <div class="list-content-inner">
          <table v-if="isKol" class="default-table home-recom">
            <thead>
              <tr>
                <th width="40%"></th>
                <th width="20%" class="text-center small">
                  <p>{{$t('lang.homePage.recommend.influence')}}</p>
                  <p>
                    {{$t('lang.homePage.recommend.influenceScore')}}
                    <span
                      class="kol-data-rank recomInfluence"
                      @click="orderBy(1)"
                    >
                      <i :class="{down: true, 'is-bottom-iactive': isInflueceActive}"></i>
                    </span>
                  </p>
                </th>
                <th width="20%" class="text-center small">
                  <p>
                    {{$t('lang.homePage.recommend.correlation')}}
                    <span
                      class="kol-data-rank recomCorrel"
                      @click="orderBy(3)"
                    >
                      <i :class="{down: true, 'is-bottom-iactive': isCorrelActive}"></i>
                    </span>
                  </p>
                </th>
                <th width="20%" class="text-center small">
                  <p>{{$t('lang.homePage.recommend.trust')}}</p>
                  <p>
                    {{$t('lang.homePage.recommend.trustIndex')}}
                    <span
                      class="kol-data-rank recomTrustIndex"
                      @click="orderBy(2)"
                      v-if="tabIndex === 0"
                    >
                      <i :class="{down: true, 'is-bottom-iactive': isTrustActive}"></i>
                    </span>
                  </p>
                </th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="item in currentList" :key="item.profile_id">
                <td>
                  <kols-list-item
                    :key="item.profile_id"
                    :renderStatus="kolRenderStatus"
                    :renderData="item"
                    :routerData="kolRouterData"
                  ></kols-list-item>
                </td>
                <td class="text-center small">
                  <p>{{item.avg_post_influences_percentage}}</p>
                </td>
                <td class="text-center small">
                  <p>{{item.correlation_percentage}}</p>
                </td>
                <td class="text-center small">
                  <p v-if="kolRenderStatus.type === 0">{{item.cooperation_score_percentage}}</p>
                  <p v-else>
                    Coming
                    <br />Soon
                  </p>
                </td>
              </tr>
            </tbody>
          </table>
          <div class="nonetip" v-if="isBrandShow">
            <span>{{$t('lang.homePage.noBrand')}}</span>
          </div>
          <div class="nonetip" v-if="isShow">
            <span>{{$t('lang.totalNoDataTip')}}</span>
          </div>
          <div class="r8-loading" v-if="isLoading">
            <a-spin tip="Loading..." />
          </div>
        </div>
      </div>

      <div class="panel-foot">
        <button
          type="button"
          class="btn btn-sm btn-block btn-cyan"
          @click="toKolDetailMore"
        >{{$t('lang.more')}}</button>

        <!-- <button @click="showWindow">我想展示弹窗</button>
        <button @click="hidewindow">我想关闭弹窗</button> -->
      </div>
    </default-tabs>
  </div>
</template>

<script>
import axios from "axios";
import apiConfig from "@/config";
import commonJs from "@javascripts/common.js";
import DefaultTabs from "@components/DefaultTabs";
import KolsListItem from "@components/KolsListItem";
import { mapState, mapMutations } from "vuex";
import store from '@/store'

export default {
  props: ["childKeyList", "isSelectBrand"],
  components: {
    DefaultTabs,
    KolsListItem
  },
  data() {
    return {
      isBrandShow: false,
      kolRenderStatus: {
        hasLiked: false,
        hasMsg: false,
        hasChecked: false,
        hasInflunce: true,
        hasCart: false,
        hasDelete: false,
        isTags: true,
        type: 0
      },
      kolRouterData: {
        type: "",
        keywords: ""
      },
      tabIndex: 0,
      isShow: false,
      isLoading: true,
      isKol: false,
      params: {
        start_date: commonJs.cPastYears,
        end_date: commonJs.cPastOneday,
        brand_keywords: "",
        //sortActiveNum = 1 = > influence =》 order_by: "influence"
        //sortActiveNum = 2 = > Content quality score =》 order_by: "cooperation_score"
        //sortActiveNum = 3 = > correlation =》 order_by: "correlation"
        order_by: "influence"
      },
      currentList: [],
      tabList: [
        {
          index: 0,
          name: "weibo",
          iconClass: "weibo"
        },
        {
          index: 1,
          name: "wechat",
          iconClass: "wechat"
        },
        {
          index: 2,
          name: "xiaohongshu",
          iconClass: "xiaohongshu"
        },
        {
          index: 5,
          name: "douyin",
          iconClass: "douyin"
        }
      ],
      isInflueceActive: true,
      isTrustActive: false,
      isCorrelActive: false,
      sortActiveNum: 1
    };
  },
  computed: {
    ...mapState(["authorization"])
  },
  watch: {
    childKeyList: {
      handler() {
        if (this.isSelectBrand) {
          // console.log('woshiyou watch 有品牌')
          // console.log(this.childKeyList.brand_keywords)
          this.isBrandShow = false;
          this.isShow = false;
          this.isLoading = true;
          this.isKol = false;
          this.isInflueceActive = true;
          this.isTrustActive = false;
          this.isCorrelActive = false;
          this.params.order_by = "influence";
          if (this.childKeyList.brand_keywords !== "") {
            let newKey = "";
            this.childKeyList.brand_keywords.split(",").forEach(item => {
              newKey += '"' + item.replace(/^\s+|\s+$/g, "") + '" ';
            });
            this.params.brand_keywords = newKey;
            // 传给当前列 kolsListItem.vue 的值 传原始的 this.childKeyList.brand_keywords 因为在 kolsListItem.vue中会再次传给detail detail 再做截取的判断
            this.kolRouterData.keywords = this.childKeyList.brand_keywords;

            // 调用判断是哪个平台的接口
            this.JudgePlatform(this.tabIndex, this.params);
          }
        } else {
          // console.log('woshiyou watch无品牌')
          this.tabIndex = 0;
          this.isBrandShow = true;
          this.isLoading = false;
          this.isShow = false;
          this.isKol = false;
        }
      },
      immediate: true,
      deep: true
    }
  },
  created() {},
  methods: {
    // 尝试控制 组件的弹窗
    // ...mapMutations(['setChatWindow']),
    // showWindow() {
    //   // console.log('woshi')
    //   store.commit('setChatWindow', true)
    // },
    // hidewindow() {
    //   store.commit('setChatWindow', false)
    // },
    // 调用接口判断
    JudgePlatform(type, params) {
      if (Number(type) === 0) {
        // 微博接口
        this.weiboKol(params);
      }
      if (Number(type) === 1) {
        // 微信接口
        this.weixinKol(params);
      }
      if (Number(type) === 2) {
        // 小红书接口
        this.xiaohongshuKol(params);
      }
      if (Number(type) === 5) {
        // 抖音接口
        this.douyinKol(params);
      }
    },
    changeTab(tab) {
      this.tabIndex = tab.index;
      this.kolRenderStatus.type = tab.index;
      this.currentList = [];
      this.isShow = false;
      this.isLoading = true;
      this.isBrandShow = false;
      this.isInflueceActive = true;
      this.isTrustActive = false;
      this.isCorrelActive = false;
      this.params.order_by = "influence";
      if (this.isSelectBrand) {
        // 调用判断是哪个平台的接口
        this.JudgePlatform(tab.index, this.params);
      } else {
        this.isBrandShow = true;
        this.isLoading = false;
        this.isKol = false;
      }
      this.kolRouterData.type = tab.index;
    },
    // 跳转kol list
    toKolDetailMore() {
      this.$router.push({
        path: "/kol/list",
        name: "KolList",
        query: {
          brand_keywords: this.childKeyList.brand_keywords,
          type: this.tabIndex
        }
      });
    },
    // 微博的接口
    weiboKol(params) {
      const _that = this;
      axios
        .post(apiConfig.kolsWeibo, params, {
          headers: {
            Authorization: _that.authorization
          }
        })
        .then(function(res) {
          _that.isLoading = false;
          if (res.data.length === 0 || !res.data.length) {
            _that.isShow = true;
            _that.isBrandShow = false;
            _that.isKol = false;
          } else {
            _that.isShow = false;
            _that.isBrandShow = false;
            _that.isKol = true;
            _that.currentList = res.data.slice(0, 5);
            _that.currentList.forEach((element, index) => {
              //    alert (JSON.stringify(element));
              if (
                element.cooperation_score ||
                element.cooperation_score === 0
              ) {
                element.cooperation_score_percentage =
                  commonJs.roundTo(element.cooperation_score / 10, 2) + "%";
              } else {
                element.cooperation_score_percentage = "N/A";
              }
              if (
                element.avg_post_influences ||
                element.avg_post_influences === 0
              ) {
                element.avg_post_influences_percentage =
                  commonJs.roundTo(element.avg_post_influences / 10, 2) + "%";
              } else {
                element.avg_post_influences_percentage = "N/A";
              }
              if (element.correlation || element.correlation === 0) {
                element.correlation_percentage =
                  commonJs.roundTo(element.correlation, 2) + "%";
              } else {
                element.correlation_percentage = "N/A";
              }
            });
          }
        })
        .catch(function(error) {
          // console.log(error)
        });
    },
    // 微信的接口
    weixinKol(params) {
      const _that = this;
      axios
        .post(apiConfig.kolsWeixin, params, {
          headers: {
            Authorization: _that.authorization
          }
        })
        .then(function(res) {
          _that.isLoading = false;
          if (res.data.length === 0 || !res.data.length) {
            _that.isShow = true;
            _that.isKol = false;
          } else {
            _that.isShow = false;
            _that.isKol = true;
            _that.currentList = res.data.slice(0, 5);
            _that.currentList.forEach((element, index) => {
              //    alert (JSON.stringify(element));
              if (
                element.cooperation_score ||
                element.cooperation_score === 0
              ) {
                element.cooperation_score_percentage =
                  commonJs.roundTo(element.cooperation_score / 10, 2) + "%";
              } else {
                element.cooperation_score_percentage = "N/A";
              }
              if (
                element.avg_post_influences ||
                element.avg_post_influences === 0
              ) {
                element.avg_post_influences_percentage =
                  commonJs.roundTo(element.avg_post_influences / 10, 2) + "%";
              } else {
                element.avg_post_influences_percentage = "N/A";
              }
              if (element.correlation || element.correlation === 0) {
                element.correlation_percentage =
                  commonJs.roundTo(element.correlation, 2) + "%";
              } else {
                element.correlation_percentage = "N/A";
              }
            });
          }
        })
        .catch(function(error) {
          // console.log(error)
        });
    },
    // 抖音接口
    douyinKol(params) {
      const _that = this;
      axios
         .post(apiConfig.kolsDouyin, params, {
          headers: {
            Authorization: _that.authorization
          }
        })
        .then(function(res) {
          // console.log('woshi douyin', res)
          _that.isLoading = false;
          if (res.data.length === 0 || !res.data.length) {
            _that.isShow = true;
            _that.isBrandShow = false;
            _that.isKol = false;
          } else {
            _that.isShow = false;
            _that.isBrandShow = false;
            _that.isKol = true;
            _that.currentList = res.data.slice(0, 5);
            _that.currentList.forEach((element, index) => {
              //    alert (JSON.stringify(element));
              if (
                element.cooperation_score ||
                element.cooperation_score === 0
              ) {
                element.cooperation_score_percentage =
                  commonJs.roundTo(element.cooperation_score / 10, 2) + "%";
              } else {
                element.cooperation_score_percentage = "N/A";
              }
              if (
                element.avg_post_influences ||
                element.avg_post_influences === 0
              ) {
                element.avg_post_influences_percentage =
                  commonJs.roundTo(element.avg_post_influences / 10, 2) + "%";
              } else {
                element.avg_post_influences_percentage = "N/A";
              }
              if (element.correlation || element.correlation === 0) {
                element.correlation_percentage =
                  commonJs.roundTo(element.correlation, 2) + "%";
              } else {
                element.correlation_percentage = "N/A";
              }
            });
          }
        })
        .catch(function(error) {
          // console.log(error)
        });
    },
    xiaohongshuKol(params) {
      const _that = this;
      axios
         .post(apiConfig.kolsXiaohongshu, params, {
          headers: {
            Authorization: _that.authorization
          }
        })
        .then(function(res) {
          // console.log('woshi kolsXiaohongshu', res)
          _that.isLoading = false;
          if (res.data.length === 0 || !res.data.length) {
            _that.isShow = true;
            _that.isBrandShow = false;
            _that.isKol = false;
          } else {
            _that.isShow = false;
            _that.isBrandShow = false;
            _that.isKol = true;
            _that.currentList = res.data.slice(0, 5);
            _that.currentList.forEach((element, index) => {
              //    alert (JSON.stringify(element));
              if (
                element.cooperation_score ||
                element.cooperation_score === 0
              ) {
                element.cooperation_score_percentage =
                  commonJs.roundTo(element.cooperation_score / 10, 2) + "%";
              } else {
                element.cooperation_score_percentage = "N/A";
              }
              if (
                element.avg_post_influences ||
                element.avg_post_influences === 0
              ) {
                element.avg_post_influences_percentage =
                  commonJs.roundTo(element.avg_post_influences / 10, 2) + "%";
              } else {
                element.avg_post_influences_percentage = "N/A";
              }
              if (element.correlation || element.correlation === 0) {
                element.correlation_percentage =
                  commonJs.roundTo(element.correlation, 2) + "%";
              } else {
                element.correlation_percentage = "N/A";
              }
            });
          }
        })
        .catch(function(error) {
          // console.log(error)
        });
    },
    orderBy(value) {
      this.currentList = [];
      this.isShow = false;
      this.isLoading = true;
      this.isBrandShow = false;
      if (value === 1) {
        this.sortActiveNum = 1;
        this.params.order_by = "influence";
        this.isInflueceActive = true;
        this.isTrustActive = false;
        this.isCorrelActive = false;
        this.JudgePlatform(this.tabIndex, this.params);
      }
      if (value === 2) {
        this.sortActiveNum = 2;
        this.params.order_by = "cooperation_score";
        this.isInflueceActive = false;
        this.isTrustActive = true;
        this.isCorrelActive = false;
        this.JudgePlatform(this.tabIndex, this.params);
      }
      if (value === 3) {
        this.sortActiveNum = 3;
        this.params.order_by = "correlation";
        this.isInflueceActive = false;
        this.isTrustActive = false;
        this.isCorrelActive = true;
        this.JudgePlatform(this.tabIndex, this.params);
      }
    }
  },
  mounted() {
    this.kolRouterData.type = this.tabIndex;
  }
};
</script>

<style lang="scss" scoped>
.home-top-post /deep/ .tab-label {
  margin-bottom: 10px;
}
.list-content {
  padding: 10px 0;
  height: 400px;
  overflow: hidden;
  @include respond-to(mobile) {
    height: auto;
  }
  .kols-list-item {
    &:after {
      height: 2px;
      background-color: #e1e8ea;
    }
    &:last-child:after {
      background-color: transparent;
    }
  }
}
.list-content-inner {
  height: 380px;
  padding: 0 20px;
  overflow-y: auto;
  @include respond-to(mobile) {
    height: auto;
  }
  .default-table {
    th {
      padding: 0;
      font-weight: bold;
      background-color: transparent;
    }
    .small {
      font-size: 1.2rem;
    }
    td {
      padding: 0;
    }
  }
}
</style>
