<template>
  <div class="home-banner">
    <img src="@images/_temp/banner.jpg" alt="" class="banner-img" />
  </div>
</template>

<script>
export default {
  name: 'HomeBanner',
  data () {
    return {

    }
  }
}
</script>

<style lang="scss" scoped>
.home-banner {
  .banner-img {
    width: 100%;
  }
}
</style>
