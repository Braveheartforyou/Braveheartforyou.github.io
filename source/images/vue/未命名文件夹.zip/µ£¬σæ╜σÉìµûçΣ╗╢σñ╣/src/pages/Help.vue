<template>
  <div class="help-container">
    <div class="panel default-panel help-panel">
      <div class="panel-head">
        <h5 class="title">{{$t('lang.router.help')}}</h5>
      </div>
      <div class="panel-body">
        <p>The influence score is a number between 0 and 1000 and indicates how influential the KOL is on a social platform. A higher influence score ensures a stronger amplification of a campaign.</p>
        <p>影响力分数是0到1000之间的数字，代表KOL在社交平台上的影响力。 较高的影响力分数可确保更有效地扩大活动。</p>
        <p>The following chart shows the statistical distribution of influence scores:</p>
        <p>下图显示了影响力分数的统计分布：</p>
        <br>
        <p><img src="@images/dataExplanation/chart.png" alt=""></p>
        <br>
        <p>The average influence score is ~350, and 80% of all users have an influence score smaller than 400. The distribution of higher-than-average influence scores (> 350) follows a classical long-tail distribution.</p>
        <p>平均影响分数为~350，并且所有用户中80％的影响分数小于400. 高于平均影响分数（> 350）的分布遵循经典的长尾分布。</p>

        <p>How do we calculate the influence score? It is aggregated from the engagement (likes, shares etc.) and social reach (numbers of fans, followers etc.) of a KOL and thus strongly correlates with these two metrics. To illustrate, the following table shows some examples of WeChat users with different influence scores and provides the average engagement as a reference:</p>
        <p>我们如何计算影响力分数？它是从KOL的参与度（喜欢，分享等）和社交范围（粉丝数量，追踪数量等）汇总而来，因此与这两个指标密切相关。 为了说明，下表显示了具有不同影响力分数的微信用户的一些示例，并提供了平均参与度作为参考：</p>

        <table class="default-table mt10">
          <thead>
            <tr>
              <th>User 用户</th>
              <th class="text-center">Influence score 影响力分数</th>
              <th class="text-center">Influence score % 影响力之百分比</th>
              <th class="text-center">Average engagement per post 每篇文章的平均参与度</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>苏州预防接种</td>
              <td class="text-center">976 (high)</td>
              <td class="text-center">97.60% (high)</td>
              <td class="text-center">38335</td>
            </tr>
            <tr>
              <td>太阳幼稚园</td>
              <td class="text-center">208 (medium)</td>
              <td class="text-center">20.80% (medium)</td>
              <td class="text-center">564</td>
            </tr>
            <tr>
              <td>学会聊天的男子</td>
              <td class="text-center">6 (low)</td>
              <td class="text-center">0.6% (low)</td>
              <td class="text-center">5</td>
            </tr>
          </tbody>
        </table>

        <h6 class="title">Brand mentions: </h6>
        <p>Number of times the brand was mentioned in our social channels in the last 7 days.</p>
        <h6 class="title">品牌提及：</h6>
        <p>在过去7天内，我们的社交渠道中提及该品牌的次数。</p>

        <h6 class="title">Brand sentiment: </h6>
        <p>The sentiment score is a number between 0 (very negative) and 1 (very positive). It indicates how positive or negative the perception of the brand was in the last 7 days.</p>
        <h6 class="title">品牌情绪：</h6>
        <p>情绪分数是0（非常消极）和1（非常积极）之间的数字。 它表明该品牌在过去7天内的积极或消极态度。</p>

        <h6 class="title">Influence score: </h6>
        <p>The influence score is aggregated from the engagement (likes, shares etc.) and social reach (numbers of fans, followers etc.) of a KOL. It indicates how influential the KOL is in the social space. A higher influence score ensures a stronger amplification of a campaign. </p>
        <h6 class="title">影响评分：</h6>
        <p>影响力得分来自KOL的参与（喜欢，分享等）和社交范围（粉丝，粉丝的数量等）。 它表明了KOL在社交空间中的影响力。较高的影响力分数可确保更有效地扩大活动。</p>

        <h6 class="title">Influence score %: </h6>
        <p>Percentage of Influence score.</p>
        <h6 class="title">影响评分 %: </h6>
        <p>影响评分之百分比。</p>

        <h6 class="title">Performance (CPC): </h6>
        <p>The performance is measured in terms of CPC (cost-per-click).</p>
        <h6 class="title">绩效（CPC）：</h6>
        <p>性能以CPC（每次点击费用）衡量。</p>

        <h6 class="title">Keywords:</h6>
        <p>The tag cloud shows keywords (brands, products, locations and other attributes) that frequently occur in the content of the KOL. </p>
        <h6 class="title">关键字：</h6>
        <p>标签云显示KOL内容中经常出现的关键字（品牌，产品，位置和其他属性）。</p>

        <h6 class="title">Number of clients: </h6>
        <p>The number of clients that this KOL works for. A high number of clients indicates a track record that proves the amplification potential of a KOL. On the other hand, a KOL who has not worked for other brands yet or worked only for a few brands might be an attractive and economic choice since he does not yet have a reputation of producing commercial content.</p>
        <h6 class="title">客户数量：</h6>
        <p>此KOL适用的客户端数量。 大量客户表示跟踪记录证明了KOL的放大潜力。另一方面，一个尚未为其他品牌工作或仅为少数品牌工作的KOL可能是一个有吸引力和经济的选择，因为他还没有生产商业内容的声誉。</p>
        <h6 class="title">Content quality score:</h6>
        <p>The Content quality score combine multiple factors which reflect the quality of a KOL as well as his suitability to work with Robin8 and our customers. In general, the score promotes personal users that post lots of varied, original content. It penalises professional users (media/brand/government) and users who post a lot of repeated and/or shared content. The detail components of the index are as follows, along with the kind of users they promote / penalize: </p>

        <table class="default-table cooperation-table mt10">
          <thead>
            <tr>
              <th>&nbsp;</th>
              <th>Algorithm</th>
              <th>Promoted users</th>
              <th>Penalized users</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td class="cooperation-table-bold">1、Content originality</td>
              <td>compare ratio of retweets vs. original posts</td>
              <td>content creaters</td>
              <td>users who mainly share content of other users</td>
            </tr>
            <tr>
              <td class="cooperation-table-bold">2、Content variety</td>
              <td>duplicate and near-duplicate detection</td>
              <td>users who post new content</td>
              <td>users with lots of duplicates or near-duplicate</td>
            </tr>
            <tr>
              <td class="cooperation-table-bold">3、Personality</td>
              <td>analysis of user name</td>
              <td>people accounts</td>
              <td>media/brand/government accounts</td>
            </tr>
            <tr>
              <td class="cooperation-table-bold">4、Authenticity of data</td>
              <td>analysis of post content for 'personal' language （ ex. 1st person pronouns ）and commercial language（shopping/sales terms, special emojis etc.）</td>
              <td>users who post personal,relatable content</td>
              <td>users who post lots of commercial/ad content</td>
            </tr>
          </tbody>
        </table>
        <p class="mt20">The average value of the cooperation is score is 657.3, and most KOLs have a cooperation score between 550 and 800. If a KOL has a cooperation score below 500, we advise a detailed check of his activity and references. Please contact us in case you need assistance with selecting appropriate KOLs. </p>
        <h6 class="title">内容价值指数:</h6>
        <p>内容价值指数结合了多种因素，反映了KOL的质量以及他与Robin8和我们的客户合作的适宜性。总的来说，该索引促进个人用户发布许多不同的原始内容。它惩罚专业用户（媒体/品牌/政府）和发布大量重复和/或共享内容的用户。索引的详细组成部分如下，以及他们推广/处罚的用户类型：</p>

        <table class="default-table cooperation-table mt10">
          <thead>
            <tr>
              <th>&nbsp;</th>
              <th>算法</th>
              <th>提升的用户 </th>
              <th>处罚用户</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td class="cooperation-table-bold">1、内容创意</td>
              <td>比较转载与原始文章的比率 </td>
              <td>内容创建者</td>
              <td>主要共享其他用户内容的用户</td>
            </tr>
            <tr>
              <td class="cooperation-table-bold">2、内容多样性</td>
              <td>重复和近重复检测</td>
              <td>发布新内容的用户 </td>
              <td>具有大量重复或接近重复的用户</td>
            </tr>
            <tr>
              <td class="cooperation-table-bold">3、个性</td>
              <td>用户名分析</td>
              <td>人员帐户 </td>
              <td>媒体/品牌/政府账户 </td>
            </tr>
            <tr>
              <td class="cooperation-table-bold">4、数据真实性</td>
              <td>分析“个人”语言（如第一人称代词）和商业语言（购物/销售术语、特殊表情符号等）的帖子内容。</td>
              <td>发布个人、可关联内容的用户</td>
              <td>发布大量商业/广告内容的用户</td>
            </tr>
          </tbody>
        </table>
        <p class="mt20">合作的平均值为657.3分，大多数KOL的合作得分在550到800分之间。如果KOL的合作分数低于500，我们建议对其活动和参考资料进行详细检查。如果您需要帮助选择合适的KOL，请联系我们。</p>
        <h6 class="title">Content Quality Score %: </h6>
        <p>Percentage of Content Quality Score.</p>
        <h6 class="title">内容价值指数%：</h6>
        <p>内容价值指数之百分比。</p>

        <h6 class="title">KOLO (KOL Opportunity)：</h6>
        <p>The KOLO platform provides brands owners with a range of KOLs, including weibo、wechat、xiaohongshu、douyin、kuaishou、facebook、instagram and so on. The brand owner can view the opportunities submitted by KOLs and directly communicate with them.</p>

        <h6 class="title">KOLO (KOL 机会)：</h6>
        <p>KOLO平台为品牌主提供包括微博、微信、抖音、小红书、快手、facebook、Instagram等30余个社交媒体平台KOL的合作意向。品牌主可以在KOLO平台查看KOL提交的机会，与感兴趣的KOL直接进行交流。</p>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios'
import apiConfig from '@/config'

export default {
  name: 'Help',
  components: {
  },
  data () {
    return {
    }
  },
}
</script>

<style lang="scss" scoped>
.help-container {
  padding: 30px 100px;
  @include respond-to(mobile) {
    padding: 16px;
  }
}
.help-panel {
  line-height: 2;
  .panel-body {
    padding: 40px;
    text-align: justify;
    @include respond-to(mobile) {
      padding: 16px;
    }
    .title {
      margin-top: 30px;
      font-size: $font-nm-b;
    }
    * {
      max-width: 100%;
    }
  }
}
.cooperation-table{
  td {
    width: 27%;
  }
  .cooperation-table-bold{
    font-weight: bold;
    width: 20%;
    font-size: $font-sm;
  }
}
</style>
