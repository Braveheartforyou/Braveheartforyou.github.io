<template>
  <div class="page-footer">
    <!-- <div class="container footer-container text-center">©Copyright 2015-2019 Robin8 All Rights Reserved. 络鬓科技（上海）有限公司 版权所有</div> -->

    <customer-service></customer-service>
    <chating-window v-if='fixedMassgeBtn'></chating-window>
  </div>
</template>

<script>
import { mapState, mapMutations } from 'vuex'
// 联系二维码
import CustomerService from '@components/CustomerService'
// 聊天窗口
import ChatingWindow from '@components/ChatingWindow'

export default {
  name: 'PageFooter',
  components: {
    CustomerService,
    ChatingWindow
  },
  data () {
    return {
      showBtn: false
    }
  },
  computed: {
    ...mapState(['fixedMassgeBtn']),
    // listenFixedMassgeBtn() {
    //   return this.fixedMassgeBtn
    // }
  },
  watch: {
    // listenFixedMassgeBtn: {
    //   handler() {
    //     console.log(this.fixedMassgeBtn)
    //     this.showBtn = this.fixedMassgeBtn
    //   }
    // },
  }
}
</script>

<style lang="scss" scoped>
.footer-container {
  padding: 40px 0;
  margin-top: 60px;
}
</style>
