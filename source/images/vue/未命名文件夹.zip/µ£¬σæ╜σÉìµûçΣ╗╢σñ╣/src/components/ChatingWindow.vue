<template>
  <div class="chat-wrap">
    <div class="chat-icon" @click="showChatList">
      <i class="cl-info-count-tip" v-if="Number(messageCount) > 0">{{messageCount}}</i>
      <span class="iconfont icon-liaotian"></span>
    </div>
    <div class="chat-window" v-if="isShowChat">
      <div class="cw-header row">
        <div class="col-xs-10 cwheader-info">
          <b></b>
          <span>{{userName}}</span>
        </div>
        <div class="col-xs-2 cwheader-plugins">
          <span class="iconfont icon-close" @click="hideChat"></span>
        </div>
      </div>
      <div class="cw-content-wrap">
        <div class="cw-content" v-if="cwContent">
          <div class="cw-content-list" v-for="(item, index) in currentChatList" :key="index">
            <!-- 消息记录 -->
            <div class="cw-content-item cw-msg-left" v-if="Number(item.from_id) === Number(nameStatus)">
              <!-- 当前品牌主的消息 -->
              <!-- <span class="cw-msg-arrow"></span> -->
              <div class="cw-msg-main">
                <div class="cw-content-text">
                  {{item.content}} 
                </div>
                <div class="cw-content-user">
                  <div class="cw-content-userbox">
                    <img :src="item.from_avatar_url" alt="">
                  </div>
                </div>
              </div>
            </div>
            <div class="cw-content-item cw-msg-right" v-else>
               <!-- 当前kol的消息 -->
              <!-- <span class="cw-msg-arrow"></span> -->
              <div class="cw-msg-main">
                <div class="cw-content-text">
                  {{item.content}} 
                </div>
                <div class="cw-content-user">
                  <div class="cw-content-userbox">
                    <img :src="item.from_avatar_url" alt="">
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- 发送区域 -->
      <div class="chat-bottom">
        <div class="chat-input-box">
          <textarea
            type="text"
            class="form-control"
            :placeholder="$t('lang.kolList.search.keyword')"
            v-model="keyword"
          />
        </div>
        <div class="chat-send-btn">
          <button
            type="button"
            class="btn btn-cyan"
            @click="sendCotent"
          >{{$t('lang.send')}}</button>
        </div>
      </div>
    </div>
    <div class="chat-list" v-if="isShowChatList">
      <div class="cw-header row">
        <div class="col-xs-10 cwheader-info">
          <b></b>
          <span>{{nickname}}的消息列表</span>
        </div>
        <div class="col-xs-2 cwheader-plugins">
          <span class="iconfont icon-close" @click="hideChatList"></span>
        </div>
      </div>
      <div class="cl-wrap">
        <div class="nonetip mt10" v-if="isShow">
          <span>{{$t('lang.brandDisNoDataTip')}}</span>
        </div>
        <div class="r8-loading" v-if="isLoading">
          <a-spin tip="Loading..."/>
        </div>
        <div v-if="isContent" class="cl-list-content">
          <div class="cl-info-list media" v-for="(item, index) in chatDataList" :key="index" >
            <i class="cl-info-count-tip" v-if="Number(item.unreads_count) > 0">{{item.unreads_count}}</i>
            <div class="media-left media-middle" @click="toChatwindow(item)">
              <div class="cw-content-userbox">
                <img :src="item.from_avatar_url" alt="">
              </div>
            </div>
            <div class="media-body media-middle" @click="toChatwindow(item)">
              <div class="row">
                <h5 class="name col-xs-9">
                {{item.from_name}} 
                <span class="time">{{item.time}}</span></h5>
              </div>
              <p class="desc">{{item.last_content}}</p>
            </div>
            <div class="media-right media-middle">
              <span class="iconfont icon-delete" @click="deletChat(item)"></span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from "axios"
import apiConfig from "@/config"
import { mapState, mapMutations } from 'vuex'
import store from '@/store'
let currentChatingId = ''
let kolsParams = {
  locale: 'en'
}
export default {
  name: 'ChatingWindow',
  data () {
    return {
      isShowChat: false,
      isShowChatList: false,
      isShow: false,
      isLoading: true,
      isContent: false,
      keyword: '',
      imgUrl: 'https://tvax1.sinaimg.cn/crop.0.0.1125.1125.50/67bdce34ly8fvbaxuqvnij20v90v9ju0.jpg',
      userName: '',
      currentUserId: '',
      chatDataList: [],
      currentChatList: [],
      cwContent: false,
      messageCount: 0
    }
  },
  computed: {
    ...mapState(['authorization', 'showChatWindow', 'chatUserList', 'avatarImgUrl', 'nickname', 'nameStatus', 'ChatMessages', 'language']),
    listenShowChatWindow() {
      return this.showChatWindow
    },
    listenChatUserList() {
      return this.chatUserList
    },
    listenChatMessages() {
      return this.ChatMessages
    },
    listenLangue() {
      return this.language
    }
  },
  created() {
    if (this.$i18n.locale === 'zh-CN') {
			kolsParams.locale = 'zh'
		}
		if (this.$i18n.locale === 'en-US') {
			kolsParams.locale = 'en'
		}
  },
  watch: {
    listenLangue(old, newd) {
      if (old === 'zh-CN') {
        // console.log('zh')
        kolsParams.locale = 'zh'
      }
      if (old === 'en-US') {
        // console.log('en')
        kolsParams.locale = 'en'
      }
    },
    listenShowChatWindow: {
      handler() {
        // console.log(this.showChatWindow)
        this.isShowChat = this.showChatWindow
        if (this.isShowChatList === true) {
          this.isShowChatList = false
        }
      }
    },
    listenChatUserList: {
      handler() {
        // console.log('woshi 聊天的', this.chatUserList)
        const data = this.chatUserList
        // this.userName = data.profile_name
        if (data.kol_id) {
          currentChatingId = data.kol_id
          this.chatCurrentMsm(data.kol_id)
        }
      }
    },
    listenChatMessages: {
      handler() {
        // console.log(this.ChatMessages)
        this.messageCount = this.ChatMessages
      }
    },
  },
  methods: {
    // 控制setChatWindow
    ...mapMutations(['setChatWindow']),
    // 当前用户聊过的信息接口
    chatMsmsList() {
      const _that = this;
      axios.get(apiConfig.chatMsmsList, {
        headers: {
          'Authorization': this.authorization
        }
      }).then(function(res){
        if (res.status === 200) {
          _that.isLoading = false
          if (res.data.items.length > 0) {
            _that.isContent = true
            _that.isShow = false
            // console.log('我是消息的弹窗', res)
            _that.chatDataList = res.data.items
          } else {
            _that.isContent = false
            _that.isShow = true
          }
        }
      })
    },
    // 当前正在聊的kolo 接口
    chatCurrentMsm(id) {
      const _that = this;
      axios.get(apiConfig.chatMsmsList+ '/' + id, {
        params: kolsParams,
        headers: {
          'Authorization': this.authorization
        }
      }).then(function(res){
        if (res.status === 200) {
          // console.log('我是当前聊天的 kol记录', res)
          if (res.data) {
            _that.isShowChat = _that.showChatWindow
            if (res.data.items.length > 0) {
              _that.cwContent = true
              _that.currentChatList = res.data.items
              res.data.items.forEach(element => {
                if(Number(element.from_id) !== Number(_that.nameStatus)) {
                  _that.userName = element.from_name
                }
              });
              // console.log('我是当前聊天的 kol记录', res)
            } else {
              _that.cwContent = false
            }
          }
        }
      }).catch(function(error) {
        // console.log(error)
        alert('数据错误')
        // _self.canSubmit = true
      })
    },
    // 当前用户发送消息接口
    chatSend(id, params) {
      const _that = this;
      axios.post(apiConfig.chatMsmsList+ '/' + id + '/send_msm', params, {
        headers: {
          'Authorization': this.authorization
        }
      }).then(function(res){
        if (res.status === 200 || res.status === 201) {
          // console.log('发送的消息', res)
          _that.keyword = ''
          _that.chatCurrentMsm(id)
        }
      })
    },
     // 删除用户发
    deletChatlist(id, params) {
      const _that = this;
      axios.post(apiConfig.chatMsmsList+ '/' + id + '/delete', params, {
        headers: {
          'Authorization': this.authorization
        }
      }).then(function(res){
        if (res.status === 200 || res.status === 201) {
          console.log('删除', res)
          _that.chatMsmsList()
          // _that.keyword = ''
          // _that.chatCurrentMsm(id)
        }
      })
    },
    // 发送消息弹窗隐藏
    hideChat() {
      let params = {
        content: ''
      }
      this.chatSend(currentChatingId, params)
      store.commit('setChatWindow', false)
    },
    // 弹窗列表展示
    showChatList() {
      this.isShowChatList = true
      this.chatMsmsList()
    },
    // 弹窗列表隐藏
    hideChatList() {
      this.isShowChatList = false
    },
    // 从列表跳到聊天窗口
    toChatwindow(item) {
      this.isShowChatList = false
      store.commit('setChatWindow', true)
      currentChatingId = item.from_id
      this.userName = item.from_name
      this.chatCurrentMsm(item.from_id)
    },
    // 发送按钮
    sendCotent() {
      let params = {
        content: this.keyword
      }
      this.chatSend(currentChatingId, params)
    },
    deletChat(item) {
      console.log(item)
      this.deletChatlist(item.from_id)
    }
  }
}
</script>

<style lang="scss" scoped>
.name, .desc{
  @include limit-line(1);
}
</style>
