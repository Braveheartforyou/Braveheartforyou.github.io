import {FetchGet, host, searchHost, searchHostKey} from '../http';

// /**
//  * kolo 列表
//  * @param {Object} 分页
//  * @returns {Promise} 返回一个promise
//  */
// export const koloList = params => {
//     return FetchGet(host + '/opportunities', params).then((response) => {
//         return response;
//     });
// };