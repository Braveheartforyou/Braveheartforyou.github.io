/**
 * velen 封装axios 请求方式 post、get、put、delete
 * 拦截 发送请求的request、获取数据的response
 */
import axios from './server';
// 分环境打包
// 小燕
// export const host = 'http://10.150.81.53:3000/brand_api/v2'
// 张春明
// export const host = 'http://10.150.81.25:3000/brand_api/v2'
// qa
export const host = 'https://qa.robin8.net/brand_api/v2'
// 正式
// const host = 'https://robin8.net/brand_api/v2'

// fergus 接口qa地址
export const searchHost = 'https://api_beta.robin8.net/api/v1/r1'
// export fergus 接口正式地址
// export const searchHost = 'https://api_prod.robin8.net/api/v1/r1'

export const searchHostKey = '&application_id=local-001&application_key=vue-001'

// json请求头
export const oXHRHeadrs = {
  headers: {
    'Content-Type': 'application/json;charset=UTF-8'
  }
};

// url序列化请求头
export const oXHRHeadrsUrlencoded = {
  headers: {
    'Content-Type': 'application/x-www-form-urlencoded'
  }
};

// formData表单请求头
export const oXHRHeadrsFormData = {
  headers: {
    'Content-Type': 'multipart/form-data'
  }
};
// qs序列化url请求参数
export const QS = require('qs');
export default axios;
/**
 * fetch Get请求
 * @param {String} url 请求地址
 * @param {Obejct} params 請求參數
 * @param {Obejct} headers 請求头部
 * @returns {Promise} 返回一个promise
 */
export function FetchGet(url, params = {}, headers) {
  return new Promise((resolve, reject) => {
    axios.get(url, {
      params: params
    }, headers).then((response) => {
      resolve(response);
    }).catch(err => {
      reject(err);
    });
  });
}
/**
 * fetch Get请求
 * @param {String} url 请求地址
 * @param {Obejct} data 請求參數
 * @param {Obejct} headers 請求头部
 * @param {Obejct} params 请求序列化参数
 * @returns {Promise} 返回一个promise
 */
export function FetchPost(url, data = {}, headers, params) {
  return new Promise((resolve, reject) => {
    axios.post(url, data, headers, params).then((response) => {
      resolve(response);
    }).catch(err => {
      reject(err);
    });
  });
}
/**
 * fetch patch请求
 * @param {String} url 请求地址
 * @param {Obejct} data 請求參數
 * @param {Obejct} params 请求序列化参数
 * @returns {Promise} 返回一个promise
 */
export function patch(url, data = {}) {
  return new Promise((resolve, reject) => {
    axios.patch(url, data)
      .then(response => {
        resolve(response);
      }, err => {
        reject(err);
      });
  });
}
/**
 * put 方法封装
 * @param {String} url 请求路径
 * @param {Object} data 请求参数
 * @returns {Promise} 返回调用
 */
export function put(url, data = {}) {
  return new Promise((resolve, reject) => {
    axios.put(url, data)
      .then(response => {
        resolve(response);
      }, err => {
        reject(err);
      });
  });
}
