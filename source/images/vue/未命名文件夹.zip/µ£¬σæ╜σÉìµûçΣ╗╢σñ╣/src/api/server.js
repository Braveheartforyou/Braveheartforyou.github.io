import axios from 'axios'
import qs from 'qs'
// import app from '../main.js'
import store from './store'
import router from './router'

/**
 * http request 拦截器
 * 通过拦截发送的数据，比如统一添加token等等
 */
// 后端session问题
axios.defaults.withCredentials = true
axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded;charset=UTF-8'
// 接口超时处理
axios.defaults.timeout = 15000
axios.interceptors.request.use(
  config => {
    // console.log(config)
    if (store.state.authorization) {
      config.headers.Authorization = store.state.authorization
    }
    return config
  },
  err => {
    return Promise.reject(err)
  }
)


/**
 * http response 拦截器
 */
axios.interceptors.response.use(
  response => {
    // 成功请求的数据
    console.log('我是请求接口的reponse', response)
    // if (response.data) {
      
    // }
  },
  error => {
    if (error.response) {
      return Promise.reject(error.response.data)
    }
  }
)

export default axios