import * as API from './api.js';
export default API;