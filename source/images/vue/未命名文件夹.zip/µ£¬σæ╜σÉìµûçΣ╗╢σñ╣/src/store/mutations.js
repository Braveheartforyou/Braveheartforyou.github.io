import commonJs from '@javascripts/common.js'

export default {
  setAuthorization (state, token) {
    // console.log('token', state)
    // console.log('token', token)
    state.authorization = token
    try {
      commonJs.setLocalData('robin8Authorization', token, 604700)
    } catch (e) {}
  },
  setNickname (state, nickname) {
    // console.log(nickname)
    state.nickname = nickname
    try {
      commonJs.setLocalData('robin8UserName', nickname, 604700)
    } catch (e) {}
  },
  setMobile (state, mobile) {
    // console.log(mobile)
    state.mobile = mobile
    try {
      commonJs.setLocalData('robin8Mobile', mobile, 604700)
    } catch (e) {}
  },
  setAccount (state, account) {
    // console.log(account)
    state.account = account
    try {
      commonJs.setLocalData('robin8Account', account, 604700)
    } catch (e) {}
  },
  setEmail (state, email) {
    // console.log(email)
    state.email = email
    try {
      commonJs.setLocalData('robin8Email', email, 604700)
    } catch (e) {}
  },
  setAvatarImgUrl (state, avatarImgUrl) {
    // console.log(avatarImgUrl)
    state.avatarImgUrl = avatarImgUrl
    try {
      commonJs.setLocalData('robin8AvatarImgUrl', avatarImgUrl, 604700)
    } catch (e) {}
  },
  setCompany (state, company) {
    // console.log(company)
    state.company = company
    try {
      commonJs.setLocalData('robin8Company', company, 604700)
    } catch (e) {}
  },
  setCompanyName (state, companyName) {
    // console.log(companyName)
    state.companyName = companyName
    try {
      commonJs.setLocalData('robin8CompanyName', companyName, 604700)
    } catch (e) {}
  },
  setCompanyLogo (state, companyLogo) {
    // console.log(companyLogo)
    state.companyLogo = companyLogo
    try {
      commonJs.setLocalData('robin8CompanyLogo', companyLogo, 604700)
    } catch (e) {}
  },
  setLanguage (state, language) {
    // console.log(language)
    state.language = language
    try {
      commonJs.setLocalData('robin8Language', language, 604700)
    } catch (e) {}
  },
  setMsgCount (state, msg) {
    state.messages = msg
    try {
      commonJs.setLocalData('robin8Messages', msg, 604700)
    } catch (e) {}
  },
  setChatMsgCount (state, msg) {
    state.ChatMessages = msg
    try {
      commonJs.setLocalData('robin8ChatMessages', msg, 604700)
    } catch (e) {}
  },
  setDetailShow (state, data) {
    state.detailShow = data
    try {
      commonJs.setLocalData('robin8DetailShow', data, 604700)
    } catch (e) {}
  },
  setAdvancedSearchShow (state, data) {
    state.advancedSearchShow = data
    try {
      commonJs.setLocalData('robin8AdvancedSearchShow', data, 604700)
    } catch (e) {}
  },
  setNameStaus (state, data) {
    state.nameStatus = data
    try {
      commonJs.setLocalData('robin8NameStatus', data, 604700)
    } catch (e) {}
  },
  setNavOpen (state, data) {
    state.navOpen = data
  },
  setFixedMassgeBtn (state, data) {
    state.fixedMassgeBtn = data
    try {
      commonJs.setLocalData('robin8FixedMassgeBtn', data, 604700)
    } catch (e) {}
  },
  setChatWindow(state, data) {
    state.showChatWindow = data
  },
  setChatUserList(state, data) {
    state.chatUserList = data
  },
  removeAuthorization (state) {
    state.authorization = ''
    try {
      commonJs.removeLocalData('robin8Authorization')
    } catch (e) {}
  },
  removeNickname (state) {
    state.nickname = ''
    try {
      commonJs.removeLocalData('robin8UserName')
    } catch (e) {}
  },
  removeMobile (state) {
    state.mobile = ''
    try {
      commonJs.removeLocalData('robin8Mobile')
    } catch (e) {}
  },
  removeAccount (state) {
    state.account = ''
    try {
      commonJs.removeLocalData('robin8Account')
    } catch (e) {}
  },
  removeEmail (state) {
    state.email = ''
    try {
      commonJs.removeLocalData('robin8Email')
    } catch (e) {}
  },
  removeAvatarImgUrl (state) {
    state.avatarImgUrl = ''
    try {
      commonJs.removeLocalData('robin8AvatarImgUrl')
    } catch (e) {}
  },
  removeCompany (state) {
    state.company = ''
    try {
      commonJs.removeLocalData('robin8Company')
    } catch (e) {}
  },
  removeCompanyName (state) {
    state.companyName = ''
    try {
      commonJs.removeLocalData('robin8CompanyName')
    } catch (e) {}
  },
  removeCompanyLogo (state) {
    state.companyLogo = ''
    try {
      commonJs.removeLocalData('robin8CompanyLogo')
    } catch (e) {}
  },
  removeLanguage (state) {
    state.language = ''
    try {
      commonJs.removeLocalData('robin8Language')
    } catch (e) {}
  },
  removeMsgCount (state) {
    state.messages = ''
    try {
      commonJs.removeLocalData('robin8Messages')
    } catch (e) {}
  },
  removeDetailShow (state) {
    state.detailShow = ''
    try {
      commonJs.removeLocalData('robin8DetailShow')
    } catch (e) {}
  },
  removeAdvancedSearchShow (state) {
    state.advancedSearchShow = ''
    try {
      commonJs.removeLocalData('robin8AdvancedSearchShow')
    } catch (e) {}
  },
  removeNameStatus (state) {
    state.nameStatus = ''
    try {
      commonJs.removeLocalData('robin8NameStatus')
    } catch (e) {}
  },
  removeFixedMassgeBtn (state) {
    state.fixedMassgeBtn = ''
    try {
      commonJs.removeLocalData('robin8FixedMassgeBtn')
    } catch (e) {}
  },
  removeChatMsgCount (state) {
    state.ChatMessages = ''
    try {
      commonJs.removeLocalData('robin8ChatMessages')
    } catch (e) {}
  },
}
