---
title: Object的一些基本属性和方法
date: 2017-09-15 11:30:30
tags: [JavaScript, Object, ECMAScript6]
categories: [JavaScript, ECMAScript6, Object]
description: Object基本上是JavaScript中最重要的一个了
---
## 属性
JavaScript中几乎所有的对象都是 Object 的实例; 所有的对象都继承了Object.prototype的属性和方法.对象的原型的改变会传播到所有对象上，除非这些属性和方法被其他对象原型链更里层的改动所覆盖。
- Object.prototype