---
title: object_2
date: 2018-05-03 17:03:44
tags: [JavaScript, Object, ECMAScript6]
categories: [JavaScript, ECMAScript6, Object]
description: Object基本上是JavaScript中最重要的一个了(=)
---
